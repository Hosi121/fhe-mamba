#include "fideslib_plaintext_encoder.hpp"
#include "fideslib_plaintext_ops.hpp"
#include <CKKS/Context.cuh>
#include <CKKS/Plaintext.cuh>
#include <math/dftransform.h>
#include <bit>
#include <chrono>
#include <stdexcept>
#ifdef _OPENMP
#include <omp.h>
#endif

namespace fhemamba {
namespace {
void synchronize() {
  if (cudaDeviceSynchronize() != 0) throw std::runtime_error("plaintext GPU synchronization failed");
}

// Pinned FIDESlib load_convert<uint64_t> and load<uint64_t> each duplicate
// their input vector. The bridge already owns stable uint64_t staging arrays;
// copy those directly to the same limb streams and retain them through sync.
// Keep the library path for layouts outside the ordinary modulus prefix.
bool load_raw_direct(FIDESlib::CKKS::Plaintext& gpu,
                     const FIDESlib::CKKS::RawPlainText& raw) {
  if (raw.numRes <= 0 || raw.numRes > gpu.cc.L + 1 || raw.N != gpu.cc.N) return false;
  for (int i = 0; i < raw.numRes; ++i)
    if (raw.moduli[i] != gpu.cc.prime.at(i).p || raw.sub_0[i].size() != raw.N) return false;
  FIDESlib::CKKS::SetCurrentContext(gpu.cc_);
  gpu.c0.grow(raw.numRes - 1, false, raw.format != ::Format::COEFFICIENT);
  for (int i = 0; i < raw.numRes; ++i) {
    const auto position = gpu.cc.limbGPUid[i];
    auto& partition = gpu.c0.GPU.at(position.x);
    if (cudaSetDevice(partition.device) != cudaSuccess)
      throw std::runtime_error("could not select plaintext limb device");
    std::visit([&](auto& limb) {
      using Word = std::remove_pointer_t<decltype(limb.v.data)>;
      if constexpr (std::is_same_v<Word, uint64_t>) {
        if (cudaMemcpyAsync(limb.v.data, raw.sub_0[i].data(), raw.N * sizeof(uint64_t),
                            cudaMemcpyHostToDevice, limb.stream.ptr()) != cudaSuccess)
          throw std::runtime_error("direct plaintext upload failed");
      } else {
        limb.load_convert(raw.sub_0[i]);
      }
    }, partition.limb.at(position.y));
  }
  gpu.NoiseFactor = raw.Noise; gpu.NoiseLevel = raw.NoiseLevel; gpu.slots = raw.slots;
  return true;
}
}

CoefficientPlaintextEncoder::CoefficientPlaintextEncoder(Context context, uint32_t slots,
                                                       bool move_coefficients)
    : context_(std::move(context)),
      cpu_(std::any_cast<lbcrypto::CryptoContext<lbcrypto::DCRTPoly>>(context_->cpu)),
      slots_(slots), move_coefficients_(move_coefficients) {
  const auto n = cpu_->GetRingDimension();
  if (!std::has_single_bit(slots_) || slots_ > n / 2)
    throw std::invalid_argument("plaintext slots must divide N/2");
  const auto original = cpu_->GetElementParams();
  std::vector<lbcrypto::NativeInteger> moduli, roots;
  for (const auto& tower : original->GetParams()) {
    moduli.push_back(tower->GetModulus());
    roots.emplace_back(1);
  }
  for (std::size_t level = 0; level < original->GetParams().size(); ++level) {
    auto full = std::make_shared<Params>(*original);
    for (std::size_t drop = 0; drop < level; ++drop) full->PopLastParam();
    full_params_.push_back(std::move(full));
    // As in PeriodicPlaintextEncoder, identity roots suppress only the last
    // format transform, without modifying OpenFHE's process-global NTT tables.
    coefficient_params_.push_back(std::make_shared<Params>(2 * n, moduli, roots));
    moduli.pop_back(); roots.pop_back();
  }
  lbcrypto::DiscreteFourierTransform::Initialize(2 * n, slots_);
}

auto CoefficientPlaintextEncoder::encode(const std::vector<double>& values,
    uint32_t level, std::size_t degree) const -> fideslib::Plaintext {
  if (values.size() > slots_ || level >= full_params_.size() || degree == 0)
    throw std::invalid_argument("plaintext values, level or degree out of range");
  lbcrypto::Plaintext plaintext;
  {
#ifdef _OPENMP
    struct SerialIdentity {
      int previous = omp_get_max_active_levels();
      SerialIdentity() { omp_set_max_active_levels(0); }
      ~SerialIdentity() { omp_set_max_active_levels(previous); }
    } serial;
#endif
    plaintext = cpu_->MakeCKKSPackedPlaintext(values, degree, level,
                                            coefficient_params_[level], slots_);
  }
  auto& temporary = plaintext->GetElement<lbcrypto::DCRTPoly>();
  lbcrypto::DCRTPoly coefficients(full_params_[level], ::Format::COEFFICIENT, false);
  auto& output = coefficients.GetAllElements();
  auto& input = temporary.GetAllElements();
  for (std::size_t i = 0; i < output.size(); ++i) {
    if (move_coefficients_) {
      // The freshly encoded temporary exclusively owns these arrays. The
      // pinned OpenFHE exposes its unique_ptr; use its validated move setter
      // to retain each allocation while restoring real roots and COEFFICIENT
      // format. Never move from caller input or shared context parameters.
      output[i].SetValues(std::move(*input[i].m_values), ::Format::COEFFICIENT);
    } else {
      output[i].SetValues(input[i].GetValues(), ::Format::COEFFICIENT);
    }
  }
  temporary = std::move(coefficients);
  auto context_copy = context_;
  auto result = std::make_shared<fideslib::PlaintextImpl>(std::move(context_copy));
  result->cpu = std::make_any<lbcrypto::Plaintext>(std::move(plaintext));
  // Do not use the ordinary loader: the pinned version assumes EVALUATION.
  return result;
}

bool load_plaintext(fideslib::CryptoContext<fideslib::DCRTPoly>& context,
                    fideslib::Plaintext& plaintext, int ntt_batch, bool direct_upload) {
  if (ntt_batch <= 0) throw std::invalid_argument("NTT batch must be positive");
  if (plaintext->loaded) return false;
  if (!context->loaded || context->devices.empty())
    throw std::invalid_argument("plaintext upload requires a loaded GPU context");
  const auto& cpu = std::any_cast<const lbcrypto::Plaintext&>(plaintext->cpu);
  const auto& poly = cpu->GetElement<lbcrypto::DCRTPoly>();
  const auto& limbs = poly.GetAllElements();
  FIDESlib::CKKS::RawPlainText raw{};
  raw.originalPlainText = cpu;
  raw.numRes = limbs.size(); raw.N = poly.GetRingDimension(); raw.format = poly.GetFormat();
  raw.Noise = cpu->GetScalingFactor(); raw.NoiseLevel = cpu->GetNoiseScaleDeg();
  raw.slots = cpu->GetSlots();
  raw.sub_0.reserve(limbs.size()); raw.moduli.reserve(limbs.size());
  for (const auto& limb : limbs) {
    const auto& values = limb.GetValues();
    auto& output = raw.sub_0.emplace_back(values.GetLength());
    for (std::size_t i = 0; i < output.size(); ++i) output[i] = values[i].ConvertToInt();
    raw.moduli.push_back(limb.GetModulus().ConvertToInt());
  }
  auto& gpu_context = std::any_cast<FIDESlib::CKKS::Context&>(context->gpu);
  auto gpu = std::make_shared<FIDESlib::CKKS::Plaintext>(gpu_context);
  // Constant plaintext buffers omit NTT scratch. Allocate ordinary limbs
  // (including aux pointers) before loadConstant so the transform can use them.
  const bool direct = direct_upload && load_raw_direct(*gpu, raw);
  if (!direct) {
    if (raw.format == ::Format::COEFFICIENT) gpu->c0.grow(raw.numRes - 1);
    gpu->load(raw);
  }
  if (raw.format == ::Format::COEFFICIENT) gpu->c0.NTT(ntt_batch, true);
  synchronize(); // raw owns the staging vectors; neither loader nor NTT may outlive them.
  plaintext->gpu = context->RegisterDevicePlaintext(std::move(gpu));
  plaintext->loaded = true;
  return direct;
}

auto readback_plaintext(const fideslib::Plaintext& plaintext) -> lbcrypto::DCRTPoly {
  if (!plaintext->loaded) throw std::invalid_argument("plaintext is not loaded");
  auto& cc = plaintext->parent_context;
  auto gpu = std::static_pointer_cast<FIDESlib::CKKS::Plaintext>(cc->GetDevicePlaintext(plaintext->gpu));
  FIDESlib::CKKS::RawPlainText raw{};
  gpu->store(raw); synchronize();
  const auto& cpu = std::any_cast<const lbcrypto::Plaintext&>(plaintext->cpu);
  lbcrypto::DCRTPoly out(cpu->GetElement<lbcrypto::DCRTPoly>().GetParams(), ::Format::EVALUATION, false);
  auto& limbs = out.GetAllElements();
  if (raw.sub_0.size() != limbs.size()) throw std::runtime_error("GPU plaintext limb count differs");
  for (std::size_t i = 0; i < limbs.size(); ++i) {
    lbcrypto::NativeVector values(raw.sub_0[i].size(), limbs[i].GetModulus());
    for (std::size_t j = 0; j < values.GetLength(); ++j) values[j] = raw.sub_0[i][j];
    limbs[i].SetValues(std::move(values), ::Format::EVALUATION);
  }
  return out;
}

PlaintextPreparation::PlaintextPreparation(Context context, uint32_t slots,
    bool fast_upload, bool gpu_ntt, bool profile, bool direct_upload)
    : context_(std::move(context)), slots_(slots),
      fast_upload_(fast_upload || gpu_ntt || direct_upload), profile_(profile),
      direct_upload_(direct_upload) {
  if (gpu_ntt) coefficient_ = std::make_unique<CoefficientPlaintextEncoder>(context_, slots_);
}

void PlaintextPreparation::enable_periodic_encoding(uint32_t slots) {
  periodic_ = std::make_unique<stage1::PeriodicPlaintextEncoder>(context_, slots);
}

auto PlaintextPreparation::encode(const std::vector<double>& values, uint32_t level,
    std::size_t degree, uint32_t packing_slots) -> fideslib::Plaintext {
  if (packing_slots && periodic_) {
    if (packing_slots != periodic_->slots())
      throw std::invalid_argument("unexpected periodic plaintext slot count");
    ++subring_encodes;
    return periodic_->encode(values, level, degree);
  }
  if (coefficient_ && (!packing_slots || packing_slots == slots_)) {
    ++gpu_ntt_encodes;
    return coefficient_->encode(values, level, degree);
  }
  return context_->MakeCKKSPackedPlaintext(
      values, degree, level, nullptr, packing_slots ? packing_slots : slots_);
}

auto PlaintextPreparation::align_addend(const Ciphertext& ciphertext,
    fideslib::Plaintext plaintext, const std::vector<double>& values,
    long long& reencodes) -> fideslib::Plaintext {
  return stage1::additive_plaintext(ciphertext, std::move(plaintext), values, reencodes,
      [&](const auto& v, uint32_t level, std::size_t degree) {
        return encode(v, level, degree);
      });
}

auto PlaintextPreparation::encode_addend(const Ciphertext& ciphertext,
    const std::vector<double>& values, long long& reencodes) -> fideslib::Plaintext {
  if (coefficient_) return encode(values, ciphertext->GetLevel(), ciphertext->GetNoiseScaleDeg());
  return align_addend(ciphertext, encode(values, ciphertext->GetLevel()), values, reencodes);
}

void PlaintextPreparation::load(fideslib::Plaintext& plaintext) {
  if (!fast_upload_ || plaintext->loaded) return;
  const auto start = profile_ ? std::chrono::steady_clock::now() : std::chrono::steady_clock::time_point{};
  if (load_plaintext(context_, plaintext, kPlaintextNttBatch, direct_upload_)) ++direct_uploads;
  ++fast_uploads;
  if (profile_) upload_seconds += std::chrono::duration<double>(
      std::chrono::steady_clock::now() - start).count();
}

}  // namespace fhemamba
