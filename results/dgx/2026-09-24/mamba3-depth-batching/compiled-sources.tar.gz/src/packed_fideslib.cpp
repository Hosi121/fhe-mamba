// Architecture-neutral packed CKKS executor. Evaluation has no decryption API.
#include <fideslib.hpp>
#include "packed_program.hpp"
#include "packed_routing.hpp"
#include "packed_depth.hpp"
#include "fideslib_plaintext_ops.hpp"
#include "stage1_mamba2_plan.hpp"

#include <algorithm>
#include <chrono>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <cstdint>
#include <sys/resource.h>

extern "C" int cudaDeviceSynchronize(void);
using namespace fideslib;
using Ct = Ciphertext<DCRTPoly>;
using Clock = std::chrono::steady_clock;
static void sync_gpu() {
  if (cudaDeviceSynchronize() != 0) throw std::runtime_error("CUDA synchronization failed");
}
static double elapsed(Clock::time_point start) {
  return std::chrono::duration<double>(Clock::now() - start).count();
}

struct PackedEvaluator {
  CryptoContext<DCRTPoly> cc;
  PublicKey<DCRTPoly> public_key;
  int slots;
  double bound;
  long long ct_ct = 0, ct_pt = 0, rotations = 0, adds = 0, bootstraps = 0, reencodes = 0;
  double bootstrap_seconds = 0;
  bool replicated_linear = true;
  bool legacy_routing = false;
  bool trace_levels = false;
  bool planned_refresh = false;
  bool batch_refresh = false;
  int bootstrap_passes = 2;
  long long logical_refreshes = 0, refresh_batches = 0, largest_refresh_batch = 1;
  long long evaluated_nodes = 0;
  int planned_logical_refreshes = 0;
  struct OperationStats { double seconds = 0, bootstrap_seconds = 0; long long nodes = 0, bootstraps = 0; };
  std::map<std::string, OperationStats> operation_stats;
  std::function<Ct(const Ct&)> client_feedback;
  double current_bound = 64;

  auto scale(const Ct& a, double c) -> Ct {
    ++ct_pt; auto out = a->Clone(); cc->EvalMultInPlace(out, c); sync_gpu(); return out;
  }
  auto aligned(const Ct& a, const Ct& b) -> std::pair<Ct, Ct> {
    auto x = a->Clone(), y = b->Clone();
    auto level = std::max(x->GetLevel(), y->GetLevel());
    x->SetLevel(level); y->SetLevel(level); return {x, y};
  }
  auto add(const Ct& a, const Ct& b) -> Ct {
    auto [x, y] = aligned(a, b); ++adds; auto out = cc->EvalAdd(x, y); sync_gpu(); return out;
  }
  auto mul(const Ct& a, const Ct& b) -> Ct {
    auto [x, y] = aligned(a, b); ++ct_ct; auto out = cc->EvalMult(x, y); sync_gpu(); return out;
  }
  auto scalar_add(const Ct& a, double b) -> Ct { ++adds; return cc->EvalAdd(a, b); }
  auto plain(const Ct& a, std::vector<double> values, bool multiply) -> Ct {
    values.resize(slots);
    auto p = cc->MakeCKKSPackedPlaintext(values, 1, a->GetLevel(), nullptr, slots);
    if (multiply) { ++ct_pt; auto out = cc->EvalMult(a, p); sync_gpu(); return out; }
    p = fhemamba::stage1::additive_plaintext(cc, a, p, values, slots, reencodes);
    ++adds; auto out = cc->EvalAdd(a, p); sync_gpu(); return out;
  }
  auto encrypt(std::vector<double> values) -> Ct {
    values.resize(slots);
    auto p = cc->MakeCKKSPackedPlaintext(values, 1, 0, nullptr, slots);
    return cc->Encrypt(public_key, p);
  }
  auto rotate(const Ct& value, int offset) -> Ct {
    offset %= slots;
    if (offset > slots / 2) offset -= slots;
    if (offset < -slots / 2) offset += slots;
    auto out = value;
    const int sign = offset < 0 ? -1 : 1;
    for (int bits = std::abs(offset), power = 1; bits; bits >>= 1, power <<= 1) {
      if (bits & 1) { ++rotations; auto next = cc->EvalRotate(out, sign * power); sync_gpu(); out = next; }
    }
    return out;
  }
  auto bootstrap_components(Ct input) -> std::pair<Ct, Ct> {
    while (input->GetNoiseScaleDeg() > 1) cc->RescaleInPlace(input);
    sync_gpu(); auto first = cc->EvalBootstrap(input); sync_gpu(); ++bootstraps;
    if (bootstrap_passes == 1) return {first, {}};
    auto a = input->Clone(), b = first->Clone();
    while (b->GetNoiseScaleDeg() > 1) cc->RescaleInPlace(b);
    const auto target = std::max(a->GetLevel(), b->GetLevel());
    for (auto* v : {&a, &b}) {
      while ((*v)->GetLevel() < target) {
        *v = scale(*v, 1.0);
        while ((*v)->GetNoiseScaleDeg() > 1) cc->RescaleInPlace(*v);
      }
    }
    auto residual = cc->EvalSub(a, b); ++adds;
    residual = scale(residual, 4096.0);
    while (residual->GetNoiseScaleDeg() > 1) cc->RescaleInPlace(residual);
    sync_gpu(); auto second = cc->EvalBootstrap(residual); sync_gpu(); ++bootstraps;
    return {first, second};
  }
  auto refresh(const Ct& value, double refresh_bound) -> Ct {
    auto start = Clock::now();
    ++logical_refreshes;
    auto [first, second] = bootstrap_components(scale(value, 1.0 / refresh_bound));
    auto out = !second ? scale(first, refresh_bound) : planned_refresh
        ? add(scale(first, refresh_bound), scale(second, refresh_bound / 4096.0))
        : scale(add(first, scale(second, 1.0 / 4096.0)), refresh_bound);
    bootstrap_seconds += elapsed(start); return out;
  }
  void refresh_group(const std::vector<int>& indices, std::vector<Ct>& values,
                     const fhemamba::PackedProgram& program) {
    auto start = Clock::now();
    Ct packed;
    int offset = 0;
    for (int index : indices) {
      const auto& node = program.nodes[index];
      std::vector<double> mask(slots);
      std::fill_n(mask.begin(), node.size, 1.0 / node.bound);
      auto term = rotate(plain(values[index], std::move(mask), true), -offset);
      packed = packed ? add(packed, term) : term;
      offset += node.size;
    }
    auto [first, second] = bootstrap_components(packed);
    offset = 0;
    for (int index : indices) {
      const auto& node = program.nodes[index];
      std::vector<double> mask(slots);
      std::fill_n(mask.begin(), node.size, node.bound);
      auto a = plain(rotate(first, offset), mask, true);
      for (auto& value : mask) value /= 4096.0;
      auto b = plain(rotate(second, offset), std::move(mask), true);
      values[index] = add(a, b);
      offset += node.size;
    }
    ++refresh_batches;
    logical_refreshes += indices.size();
    largest_refresh_batch = std::max(largest_refresh_batch, static_cast<long long>(indices.size()));
    bootstrap_seconds += elapsed(start);
    if (trace_levels) {
      std::cout << "refresh_batch nodes=";
      for (int index : indices) std::cout << index << ',';
      std::cout << " occupied_slots=" << offset << std::endl;
    }
  }
  auto transform(const Ct& x, const std::map<int, std::vector<double>>& masks) -> Ct {
    Ct out;
    if (planned_refresh) {
      std::vector<int> offsets;
      for (const auto& [offset, mask] : masks) offsets.push_back(offset);
      const auto plan = fhemamba::plan_packed_diagonals(std::move(offsets), slots);
      if (plan.baby_step) {
        const int step = plan.offsets[1] - plan.offsets[0];
        std::vector<Ct> babies;
        for (int j = 0; j < plan.baby_step; ++j) babies.push_back(rotate(x, plan.offsets[j]));
        for (int first = 0; first < static_cast<int>(plan.offsets.size()); first += plan.baby_step) {
          const int giant = first * step;
          Ct inner;
          for (int j = 0; j < plan.baby_step && first + j < static_cast<int>(plan.offsets.size()); ++j) {
            auto mask = fhemamba::packed_diagonal_pre_mask(masks.at(plan.offsets[first + j]), giant);
            auto term = plain(babies[j], std::move(mask), true);
            inner = inner ? add(inner, term) : term;
          }
          auto term = rotate(inner, giant);
          out = out ? add(out, term) : term;
        }
        sync_gpu();
        return out;
      }
    }
    for (const auto& [offset, mask] : masks) {
      auto term = plain(rotate(x, offset), mask, true);
      out = out ? add(out, term) : term;
    }
    return out ? out : scale(x, 0.0);
  }
  auto gather(const Ct& x, const std::vector<double>& indices, int size, bool scatter) -> Ct {
    if (!legacy_routing && replicated_linear) {
      bool monotone = true, identity = true;
      std::set<int> offsets;
      for (int i = 0; i < static_cast<int>(indices.size()); ++i) {
        monotone = monotone && (!i || indices[i] > indices[i - 1]);
        identity = identity && indices[i] == i;
        offsets.insert(static_cast<int>(indices[i]) - i);
      }
      // Scatter sources have clean padding at node boundaries. Gather sources
      // may be a sliding reduction, so they still require a selection mask.
      if (scatter && identity) return x;
      if (monotone && offsets.size() > 32) {
        Ct out = x;
        for (const auto& stage : fhemamba::monotone_routing(indices, scatter)) {
          if (out->GetLevel() + (planned_refresh ? 1 : 3) > 39) out = refresh(out, current_bound);
          Ct next;
          for (const auto& [offset, positions] : stage) {
            std::vector<double> mask(slots);
            for (int position : positions) mask[position] = 1;
            auto term = rotate(plain(out, std::move(mask), true), offset);
            next = next ? add(next, term) : term;
          }
          out = next;
        }
        return out;
      }
    }
    std::map<int, std::vector<double>> masks;
    for (int i = 0; i < static_cast<int>(indices.size()); ++i) {
      const int source = scatter ? i : static_cast<int>(indices[i]);
      const int destination = scatter ? static_cast<int>(indices[i]) : i;
      auto& mask = masks[source - destination];
      if (mask.empty()) mask.resize(slots);
      mask[destination] = 1;
    }
    // Monotone compaction/expansion (slices, strides and head reductions).
    // Route each selected coordinate by the bits of its displacement. For
    // compaction, ascending bits keep positions strictly ordered; expansion
    // uses descending bits. This replaces thousands of diagonals by log(slots)
    // masked rotations and never merges two live coordinates.
    bool monotone = true;
    for (std::size_t i = 1; i < indices.size(); ++i)
      monotone = monotone && indices[i] > indices[i - 1];
    if (legacy_routing && replicated_linear && monotone && masks.size() > 16) {
      std::vector<int> positions(indices.size()), distance(indices.size());
      std::vector<double> selected(slots);
      int maximum = 0;
      for (int i = 0; i < static_cast<int>(indices.size()); ++i) {
        positions[i] = scatter ? i : static_cast<int>(indices[i]);
        distance[i] = static_cast<int>(indices[i]) - i;
        selected[positions[i]] = 1;
        maximum = std::max(maximum, distance[i]);
      }
      Ct out = plain(x, std::move(selected), true);
      std::vector<int> shifts;
      for (int shift = 1; shift <= maximum; shift *= 2) shifts.push_back(shift);
      if (scatter) std::reverse(shifts.begin(), shifts.end());
      for (int shift : shifts) {
        std::vector<double> moving_mask(slots);
        bool any = false;
        for (int i = 0; i < static_cast<int>(positions.size()); ++i) {
          if (distance[i] & shift) {
            any = true; moving_mask[positions[i]] = 1;
            positions[i] += scatter ? shift : -shift;
          }
        }
        if (!any) continue;
        if (out->GetLevel() + 3 > 39) out = refresh(out, current_bound);
        auto moving = plain(out, std::move(moving_mask), true);
        auto [a, b] = aligned(out, moving);
        ++adds;
        out = add(cc->EvalSub(a, b), rotate(moving, scatter ? -shift : shift));
      }
      return out;
    }
    return transform(x, masks);
  }
  auto linear(const Ct& x, const fhemamba::PackedNode& node, int columns, bool mask_output = true) -> Ct {
    if (replicated_linear && node.size + columns <= slots) {
      using namespace fhemamba::stage1;
      auto shape = resolve_interleaved_replicated_shape(node.size, columns, slots, 0);
      if (shape.replicas > 1) {
      shape.logarithmic_replication = true;
      // The shared helper reserves baby_step=1 for direct-diagonal masks.
      shape.baby_step = std::max(2, static_cast<int>(std::sqrt(shape.per_replica)));
      auto rot = [&](const Ct& a, int shift) { return rotate(a, shift); };
      auto sum = [&](const Ct& a, const Ct& b) { return add(a, b); };
      auto extended = rotation_sum(x, shape.reps, -columns, true, rot, sum);
      auto replicated = rotation_sum(extended, shape.replicas + shape.guard_windows,
                                     -shape.window, true, rot, sum);
      std::vector<Ct> babies;
      for (int i = 0; i < shape.baby_step; ++i)
        babies.push_back(rotate(replicated, i * shape.replicas));
      Ct out;
      for (int first = 0; first < shape.per_replica; first += shape.baby_step) {
        Ct inner;
        for (int j = 0; j < shape.baby_step && first + j < shape.per_replica; ++j) {
          auto mask = replicated_bsgs_pre_mask(node.data, node.size, columns,
                                               first + j, shape, slots, 0.0);
          auto term = plain(babies[j], std::move(mask), true);
          inner = inner ? add(inner, term) : term;
        }
        auto term = rotate(inner, first * shape.replicas);
        out = out ? add(out, term) : term;
      }
      out = rotation_sum(out, shape.replicas, shape.window + 1, true, rot, sum);
      if (!mask_output) { sync_gpu(); return out; }
      std::vector<double> mask(slots);
      std::fill_n(mask.begin(), node.size, 1.0);
      auto result = plain(out, std::move(mask), true);
      sync_gpu();
      return result;
      }
    }
    std::map<int, std::vector<double>> masks;
    for (int i = 0; i < node.size; ++i) for (int j = 0; j < columns; ++j) {
      const auto weight = node.data[i * columns + j];
      if (weight == 0) continue;
      auto& mask = masks[j - i];
      if (mask.empty()) mask.resize(slots);
      mask[i] = weight;
    }
    return transform(x, masks);
  }
  auto chebyshev(const Ct& x, const fhemamba::PackedNode& node) -> Ct {
    const auto lo = node.data[0], hi = node.data[1];
    std::vector<double> affine(slots), bias(slots), mask(slots);
    for (int i = 0; i < node.size; ++i) {
      affine[i] = 2 / (hi - lo); bias[i] = -(lo + hi) / (hi - lo); mask[i] = 1;
    }
    // Zero padded normalized arguments keep every inactive slot in [-1,1].
    auto u = plain(plain(x, affine, true), bias, false);
    std::vector<double> coefficients(node.data.begin() + 2, node.data.end());
    double at_zero = 0;
    if (planned_refresh) {
      // P(0) is public. P(u)-P(0) has zero inactive slots because the affine
      // map sets u=0 there. Add P(0) only to active slots, saving a mask level.
      for (int i = 0; i < static_cast<int>(coefficients.size()); i += 2)
        at_zero += (i % 4 ? -1 : 1) * coefficients[i];
      coefficients[0] -= at_zero;
    }
    int levels = 0;
    while ((1 << levels) < static_cast<int>(coefficients.size())) ++levels;
    const int baby = 1 << ((std::max(1, levels) + 1) / 2);
    std::map<int, Ct> cache{{1, u}};
    std::function<Ct(int)> basis = [&](int i) -> Ct {
      if (cache.count(i)) return cache[i];
      Ct out;
      if (i % 2 == 0) {
        auto square = mul(basis(i / 2), basis(i / 2));
        out = scalar_add(add(square, square), -1);
      } else {
        auto product = mul(basis((i + 1) / 2), basis(i / 2));
        auto [a, b] = aligned(add(product, product), u);
        out = cc->EvalSub(a, b); ++adds;
      }
      cache[i] = out; return out;
    };
    std::function<Ct(std::vector<double>)> evaluate = [&](std::vector<double> c) -> Ct {
      const int degree = static_cast<int>(c.size()) - 1;
      if (degree < baby) {
        Ct out;
        for (int i = 1; i <= degree; ++i) {
          if (std::abs(c[i]) < 1e-14) continue;
          auto term = scale(basis(i), c[i]); out = out ? add(out, term) : term;
        }
        if (!out) out = scale(u, 0.0);
        return scalar_add(out, c[0]);
      }
      int k = baby;
      while (2 * k - 1 < degree) k *= 2;
      std::vector<double> upper(c.begin() + k, c.end()), lower(c.begin(), c.begin() + k);
      for (int i = 1; i < static_cast<int>(upper.size()); ++i) upper[i] *= 2;
      for (int i = k + 1; i <= degree; ++i) lower[2 * k - i] -= c[i];
      return add(evaluate(lower), mul(basis(k), evaluate(upper)));
    };
    if (planned_refresh) {
      for (auto& value : mask) value *= at_zero;
      return plain(evaluate(coefficients), mask, false);
    }
    return plain(evaluate(coefficients), mask, true);
  }
  auto evaluate(const fhemamba::PackedProgram& program) -> std::vector<Ct> {
    fhemamba::PackedDepthPlan depth_plan;
    if (planned_refresh) {
      if (legacy_routing || !replicated_linear)
        throw std::invalid_argument("planned refresh requires replicated linear and radix8 routing");
      depth_plan = fhemamba::plan_packed_depth(program);
      planned_logical_refreshes = depth_plan.refreshes;
      std::cout << "planned_logical_refreshes=" << depth_plan.refreshes << std::endl;
    }
    std::vector<Ct> values(program.nodes.size());
    std::vector<bool> dirty(program.nodes.size());
    auto clean = [&](int index) {
      if (!dirty[index]) return;
      std::vector<double> mask(slots);
      std::fill_n(mask.begin(), program.nodes[index].size, 1);
      values[index] = plain(values[index], std::move(mask), true);
      dirty[index] = false;
    };
    std::vector<int> last(program.nodes.size());
    std::vector<std::vector<int>> consumers(program.nodes.size());
    for (int i = 0; i < static_cast<int>(program.nodes.size()); ++i)
      if (!planned_refresh || depth_plan.live[i])
        for (int parent : program.nodes[i].parents) { last[parent] = i; consumers[parent].push_back(i); }
    for (const auto& out : program.outputs) last[out.node] = program.nodes.size();
    auto refresh_value = [&](int requested, int next_operation) {
      std::vector<int> group{requested};
      int occupied = program.nodes[requested].size;
      if (batch_refresh) for (int j = 0; j < static_cast<int>(values.size()) && group.size() < 16; ++j) {
        if (j == requested || !values[j] || occupied + program.nodes[j].size > slots) continue;
        const auto use = std::lower_bound(consumers[j].begin(), consumers[j].end(), next_operation);
        if (use == consumers[j].end() || program.nodes[*use].operation == "feedback") continue;
        const int level = values[j]->GetLevel();
        if (level <= depth_plan.refreshed || (level < 33 && level + depth_plan.cost[*use] <= 39)) continue;
        group.push_back(j); occupied += program.nodes[j].size;
      }
      if (group.size() > 1) {
        refresh_group(group, values, program);
        for (int index : group) dirty[index] = false;
      } else {
        clean(requested); // Never bootstrap unmasked replica/guard coordinates.
        values[requested] = refresh(values[requested], program.nodes[requested].bound);
      }
    };
    const auto start = Clock::now();
    for (int i = 0; i < static_cast<int>(program.nodes.size()); ++i) {
      if (planned_refresh && !depth_plan.live[i]) continue;
      const auto& n = program.nodes[i];
      const auto operation_start = Clock::now();
      const auto prior_bootstrap_seconds = bootstrap_seconds;
      const auto prior_bootstraps = bootstraps;
      current_bound = n.bound;
      const auto& op = n.operation;
      int need = 3;
      if (op == "cheb") {
        int log = 0;
        while ((1 << log) < static_cast<int>(n.data.size()) - 2) ++log;
        need = log + 5;
      }
      if (planned_refresh) need = depth_plan.cost[i];
      for (int parent : n.parents) {
        if ((!planned_refresh || op != "feedback") && values[parent]->GetLevel() + need > 39) {
          refresh_value(parent, i);
        }
      }
      Ct x = n.parents.empty() ? Ct{} : values[n.parents[0]];
      if (trace_levels) {
        std::cout << "level_input node=" << i << " op=" << op << " bound=" << n.bound << " parents=";
        for (int parent : n.parents) std::cout << parent << ':' << values[parent]->GetLevel()
            << ':' << values[parent]->GetNoiseScaleDeg() << ',';
        std::cout << " refreshed=" << bootstraps - prior_bootstraps << std::endl;
      }
      Ct out;
      if (op == "input" || op == "public") out = encrypt(n.data);
      else if (op == "feedback") {
        if (!client_feedback) throw std::runtime_error("client feedback requires --client-head");
        out = client_feedback(x);
      }
      else if (op == "add") out = add(x, values[n.parents[1]]);
      else if (op == "mul") out = mul(x, values[n.parents[1]]);
      else if (planned_refresh && fhemamba::packed_negation(n)) {
        auto zero = cc->EvalSub(x, x); sync_gpu();
        out = cc->EvalSub(zero, x); adds += 2; sync_gpu();
      }
      else if (op == "addp" || op == "mulp") out = plain(x, n.data, op == "mulp");
      else if (op == "gather" || op == "scatter") out = gather(x, n.data, n.size, op == "scatter");
      else if (op == "linear" || op == "linear_ref") {
        const auto& weight = op == "linear" ? n : program.nodes[static_cast<int>(n.data[0])];
        dirty[i] = planned_refresh && depth_plan.defer_linear_mask[i];
        out = linear(x, weight, program.nodes[n.parents[0]].size, !dirty[i]);
      }
      else if (op == "cheb") out = chebyshev(x, n);
      else if (op == "repeat") {
        const int outer = n.data[0], inner = n.data[1], repeat = n.data[2];
        std::vector<double> destinations(outer * inner);
        for (int group = 0; group < outer; ++group)
          for (int j = 0; j < inner; ++j) destinations[group * inner + j] = group * inner * repeat + j;
        out = gather(x, destinations, n.size, true);
        out = fhemamba::stage1::rotation_sum(out, repeat, -inner, true,
            [&](const Ct& a, int shift) { return rotate(a, shift); },
            [&](const Ct& a, const Ct& b) { return add(a, b); });
      }
      else if (op == "sum") {
        out = x;
        const int width = static_cast<int>(n.data[0]);
        for (int step = 1; step < width; step *= 2) out = add(out, rotate(out, step));
        std::vector<double> indices(n.size);
        for (int j = 0; j < n.size; ++j) indices[j] = j * width;
        out = gather(out, indices, n.size, false);
      }
      values[i] = out;
      if (planned_refresh && depth_plan.refresh_after[i] && out->GetLevel() > depth_plan.refreshed) {
        refresh_value(i, i + 1);
        out = values[i];
      }
      sync_gpu();
      if (trace_levels) std::cout << "level_output node=" << i << " level=" << out->GetLevel()
          << " degree=" << out->GetNoiseScaleDeg() << " bootstraps=" << bootstraps - prior_bootstraps << std::endl;
      for (int parent : n.parents) if (last[parent] == i) values[parent].reset();
      auto& stats = operation_stats[op];
      ++stats.nodes;
      ++evaluated_nodes;
      stats.seconds += elapsed(operation_start);
      stats.bootstrap_seconds += bootstrap_seconds - prior_bootstrap_seconds;
      stats.bootstraps += bootstraps - prior_bootstraps;
      if (i % 10 == 0 || i + 1 == static_cast<int>(program.nodes.size())) {
        const auto seconds = elapsed(start);
        std::cout << "node=" << i + 1 << '/' << program.nodes.size() << " op=" << op
                  << " seconds=" << seconds << " eta_seconds="
                  << seconds * (program.nodes.size() - i - 1) / (i + 1)
                  << " bootstraps=" << bootstraps << std::endl;
      }
    }
    std::vector<Ct> outputs;
    for (const auto& output : program.outputs) outputs.push_back(values[output.node]);
    return outputs;
  }
};

// Protocol client: the evaluator receives only an encrypted-embedding callback.
// Public BF16 checkpoint weights are exported losslessly as little-endian FP32.
struct GenerationClient {
  uint32_t vocabulary = 0, width = 0;
  std::vector<float> weights;
  std::vector<int> tokens;
  std::vector<double> margins;
  void load(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    in.read(reinterpret_cast<char*>(&vocabulary), sizeof(vocabulary));
    in.read(reinterpret_cast<char*>(&width), sizeof(width));
    if (!in || vocabulary < 2 || vocabulary > 262144 || width < 1 || width > 8192 ||
        static_cast<uint64_t>(vocabulary) * width > 268435456)
      throw std::invalid_argument("invalid client vocabulary head");
    weights.resize(static_cast<std::size_t>(vocabulary) * width);
    in.read(reinterpret_cast<char*>(weights.data()), weights.size() * sizeof(float));
    if (!in || in.peek() != std::char_traits<char>::eof())
      throw std::invalid_argument("invalid client head length");
    for (float v : weights) if (!std::isfinite(v))
      throw std::invalid_argument("nonfinite client head");
  }
  auto select(const std::vector<double>& hidden) -> std::vector<double> {
    if (hidden.size() < width) throw std::invalid_argument("client hidden width mismatch");
    for (uint32_t j = 0; j < width; ++j)
      if (!std::isfinite(hidden[j])) throw std::runtime_error("nonfinite client output");
    int best = -1;
    double first = -INFINITY, second = -INFINITY;
    for (uint32_t token = 0; token < vocabulary; ++token) {
      double logit = 0;
      for (uint32_t j = 0; j < width; ++j)
        logit += hidden[j] * weights[static_cast<std::size_t>(token) * width + j];
      if (logit > first) { second = first; first = logit; best = token; }
      else if (logit > second) second = logit;
    }
    tokens.push_back(best); margins.push_back(first - second);
    std::cout << "client_token=" << best << " logit_margin=" << first - second << std::endl;
    const auto begin = weights.begin() + static_cast<std::size_t>(best) * width;
    return {begin, begin + width};
  }
};

auto main(int argc, char** argv) -> int {
  try {
    if (argc < 5) throw std::invalid_argument("usage: packed_fideslib PROGRAM RESULT POLY_TOL EXACT_TOL [--direct-linear] [--legacy-routing] [--planned-refresh] [--batch-refresh] [--bootstrap-passes 1|2] [--trace-levels] [--client-head FILE]");
    bool replicated_linear = true;
    bool legacy_routing = false;
    bool trace_levels = false;
    bool planned_refresh = false;
    bool batch_refresh = false;
    int bootstrap_passes = 2;
    std::string client_path;
    for (int i = 5; i < argc; ++i) {
      const std::string option = argv[i];
      if (option == "--direct-linear") replicated_linear = false;
      else if (option == "--legacy-routing") legacy_routing = true;
      else if (option == "--trace-levels") trace_levels = true;
      else if (option == "--planned-refresh") planned_refresh = true;
      else if (option == "--batch-refresh") batch_refresh = true;
      else if (option == "--bootstrap-passes" && i + 1 < argc) {
        bootstrap_passes = std::stoi(argv[++i]);
        if (bootstrap_passes != 1 && bootstrap_passes != 2)
          throw std::invalid_argument("bootstrap passes must be 1 or 2");
      }
      else if (option == "--client-head" && i + 1 < argc) client_path = argv[++i];
      else throw std::invalid_argument("unknown packed option: " + option);
    }
    const double poly_tol = std::stod(argv[3]), exact_tol = std::stod(argv[4]);
    if (batch_refresh && (!planned_refresh || bootstrap_passes != 2))
      throw std::invalid_argument("batch refresh requires planned refresh and two bootstrap passes");
    if (planned_refresh && (legacy_routing || !replicated_linear))
      throw std::invalid_argument("planned refresh requires replicated linear and radix8 routing");
    if (!std::isfinite(poly_tol) || !std::isfinite(exact_tol) || poly_tol <= 0 || exact_tol <= 0)
      throw std::invalid_argument("invalid error tolerance");
    std::ifstream input(argv[1]);
    const auto program = fhemamba::read_packed_program(input);
    GenerationClient client;
    if (!client_path.empty()) {
      client.load(client_path);
      if (program.nodes[program.outputs.back().node].size != static_cast<int>(client.width))
        throw std::invalid_argument("client head and final hidden width mismatch");
    }
    const auto setup = Clock::now();
    CCParams<CryptoContextCKKSRNS> p;
    p.SetSecurityLevel(HEStd_NotSet); p.SetSecretKeyDist(UNIFORM_TERNARY);
    p.SetCKKSDataType(REAL); p.SetRingDim(65536); p.SetBatchSize(program.slots);
    p.SetMultiplicativeDepth(44); p.SetScalingModSize(59); p.SetFirstModSize(60);
    p.SetScalingTechnique(FLEXIBLEAUTO); p.SetKeySwitchTechnique(HYBRID);
    p.SetNumLargeDigits(3); p.SetDevices({0});
    p.SetPlaintextAutoload(false); p.SetCiphertextAutoload(true);
    auto cc = GenCryptoContext(p);
    for (auto feature : {PKE, KEYSWITCH, LEVELEDSHE, ADVANCEDSHE, FHE}) cc->Enable(feature);
    auto keys = cc->KeyGen(); cc->EvalMultKeyGen(keys.secretKey);
    std::vector<int> rotations;
    for (int i = 1; i < program.slots; i *= 2) { rotations.push_back(i); rotations.push_back(-i); }
    cc->EvalRotateKeyGen(keys.secretKey, rotations);
    cc->EvalBootstrapSetup({4, 4}, {0, 0}, program.slots, 0);
    cc->EvalBootstrapKeyGen(keys.secretKey, program.slots);
    cc->LoadContext(keys.publicKey); sync_gpu();
    const double setup_seconds = elapsed(setup);
    std::cout << "setup_seconds=" << setup_seconds << std::endl;
    PackedEvaluator evaluator{cc, keys.publicKey, program.slots, program.bound};
    evaluator.replicated_linear = replicated_linear;
    evaluator.legacy_routing = legacy_routing;
    evaluator.trace_levels = trace_levels;
    evaluator.planned_refresh = planned_refresh;
    evaluator.batch_refresh = batch_refresh;
    evaluator.bootstrap_passes = bootstrap_passes;
    auto decrypt_client = [&](const Ct& value, int size) {
      Plaintext plain; auto handle = value->Clone();
      cc->Decrypt(keys.secretKey, handle, &plain);
      plain->SetLength(size); return plain->GetRealPackedValue();
    };
    if (!client_path.empty()) evaluator.client_feedback = [&](const Ct& hidden) {
      return evaluator.encrypt(client.select(decrypt_client(hidden, client.width)));
    };
    const auto start = Clock::now();
    const auto encrypted_outputs = evaluator.evaluate(program);
    sync_gpu(); const double eval_seconds = elapsed(start);
    if (!client_path.empty()) client.select(decrypt_client(encrypted_outputs.back(), client.width));
    double polynomial_error = 0, exact_error = 0;
    int non_finite = 0;
    std::vector<double> per_output_poly, per_output_exact;
    for (std::size_t i = 0; i < program.outputs.size(); ++i) {
      Plaintext plaintext; auto handle = encrypted_outputs[i]->Clone();
      cc->Decrypt(keys.secretKey, handle, &plaintext);
      plaintext->SetLength(program.outputs[i].polynomial.size());
      const auto values = plaintext->GetRealPackedValue();
      double pe = 0, ee = 0;
      for (std::size_t j = 0; j < program.outputs[i].polynomial.size(); ++j) {
        if (!std::isfinite(values[j])) { ++non_finite; continue; }
        pe = std::max(pe, std::abs(values[j] - program.outputs[i].polynomial[j]));
        ee = std::max(ee, std::abs(values[j] - program.outputs[i].exact[j]));
      }
      polynomial_error = std::max(polynomial_error, pe); exact_error = std::max(exact_error, ee);
      per_output_poly.push_back(pe); per_output_exact.push_back(ee);
    }
    const bool passed = non_finite == 0 && polynomial_error <= poly_tol && exact_error <= exact_tol;
    struct rusage usage {}; getrusage(RUSAGE_SELF, &usage);
    std::ofstream report(argv[2]);
    report << std::setprecision(12) << "{\n\"schema\":\"fhemamba-packed-result-v1\","
           << "\"backend\":\"fideslib\",\"encrypted\":true,\"security\":\"not-set\","
           << "\"passed\":" << (passed ? "true" : "false")
           << ",\"slots\":" << program.slots << ",\"ring_dimension\":65536,\"depth\":44,\"scale_bits\":59"
           << ",\"nodes\":" << program.nodes.size() << ",\"setup_seconds\":" << setup_seconds
           << ",\"evaluated_nodes\":" << evaluator.evaluated_nodes
           << ",\"eval_seconds\":" << eval_seconds << ",\"bootstrap_seconds\":" << evaluator.bootstrap_seconds
           << ",\"bootstraps\":" << evaluator.bootstraps << ",\"ct_ct_mul\":" << evaluator.ct_ct
           << ",\"ct_pt_mul\":" << evaluator.ct_pt << ",\"rotations\":" << evaluator.rotations
           << ",\"linear_method\":\"" << (evaluator.replicated_linear ? "replicated-bsgs" : "direct") << '"'
           << ",\"routing_method\":\"" << (!replicated_linear ? "direct" : legacy_routing ? "bitwise" :
                planned_refresh ? "radix8-bsgs32" : "radix8-direct32") << '"'
           << ",\"refresh_policy\":\"" << (planned_refresh ? "planned" : "baseline") << '"'
           << ",\"bootstrap_passes\":" << bootstrap_passes
           << ",\"batch_refresh\":" << (batch_refresh ? "true" : "false")
           << ",\"logical_refreshes\":" << evaluator.logical_refreshes
           << ",\"planned_logical_refreshes\":" << evaluator.planned_logical_refreshes
           << ",\"refresh_batches\":" << evaluator.refresh_batches
           << ",\"largest_refresh_batch\":" << evaluator.largest_refresh_batch
           << ",\"max_abs_error_vs_polynomial\":" << polynomial_error
           << ",\"max_abs_error_vs_exact\":" << exact_error << ",\"non_finite\":" << non_finite
           << ",\"polynomial_tolerance\":" << poly_tol << ",\"exact_tolerance\":" << exact_tol
           << ",\"peak_rss_gib\":" << usage.ru_maxrss / (1024.0 * 1024.0)
           << ",\"per_output_errors\":[";
    for (std::size_t i = 0; i < per_output_poly.size(); ++i) {
      if (i) report << ',';
      report << "{\"polynomial\":" << per_output_poly[i] << ",\"exact\":" << per_output_exact[i] << '}';
    }
    report << "],\"evaluation_decryptions\":0,\"client_output_decrypt_count\":" << client.tokens.size()
           << ",\"generated_token_ids\":[";
    for (std::size_t i = 0; i < client.tokens.size(); ++i) {
      if (i) report << ',';
      report << client.tokens[i];
    }
    report << "],\"client_logit_margins\":[";
    for (std::size_t i = 0; i < client.margins.size(); ++i) {
      if (i) report << ',';
      report << client.margins[i];
    }
    report << "],\"operation_stats\":{";
    bool first_operation = true;
    for (const auto& [name, stats] : evaluator.operation_stats) {
      if (!first_operation) report << ',';
      first_operation = false;
      report << '"' << name << "\":{\"nodes\":" << stats.nodes << ",\"seconds\":" << stats.seconds
             << ",\"bootstrap_seconds\":" << stats.bootstrap_seconds << ",\"bootstraps\":" << stats.bootstraps << '}';
    }
    report << "},\"scope\":\"" << (client_path.empty() ? "packed feasibility; inline client fixture" :
        "encrypted backbone with inline client vocabulary head and actual greedy feedback") << "\"}\n";
    if (!report) throw std::runtime_error("could not write packed result");
    std::cout << "passed=" << passed << " polynomial_error=" << polynomial_error
              << " exact_error=" << exact_error << " eval_seconds=" << eval_seconds << std::endl;
    return passed ? 0 : 1;
  } catch (const std::exception& error) {
    std::cerr << error.what() << std::endl; return 2;
  }
}
