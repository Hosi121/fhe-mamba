#include "fideslib_plaintext_encoder.hpp"
#include <CKKS/Context.cuh>
#include <CKKS/Plaintext.cuh>
#include <math/dftransform.h>
#include <bit>
#include <stdexcept>
#ifdef _OPENMP
#include <omp.h>
#endif

namespace fhemamba {
namespace {
void synchronize() {
  if (cudaDeviceSynchronize() != 0) throw std::runtime_error("plaintext GPU synchronization failed");
}
}

CoefficientPlaintextEncoder::CoefficientPlaintextEncoder(Context context, uint32_t slots)
    : context_(std::move(context)),
      cpu_(std::any_cast<lbcrypto::CryptoContext<lbcrypto::DCRTPoly>>(context_->cpu)),
      slots_(slots) {
  const auto n = cpu_->GetRingDimension();
  if (!std::has_single_bit(slots_) || slots_ > n / 2)
    throw std::invalid_argument("plaintext slots must divide N/2");
  const auto original = cpu_->GetElementParams();
  std::vector<lbcrypto::NativeInteger> moduli, roots;
  for (const auto& tower : original->GetParams()) {
    moduli.push_back(tower->GetModulus());
    roots.emplace_back(1);
  }
  for (std::size_t level = 0; level < original->GetParams().size(); ++level) {
    auto full = std::make_shared<Params>(*original);
    for (std::size_t drop = 0; drop < level; ++drop) full->PopLastParam();
    full_params_.push_back(std::move(full));
    // As in PeriodicPlaintextEncoder, identity roots suppress only the last
    // format transform, without modifying OpenFHE's process-global NTT tables.
    coefficient_params_.push_back(std::make_shared<Params>(2 * n, moduli, roots));
    moduli.pop_back(); roots.pop_back();
  }
  lbcrypto::DiscreteFourierTransform::Initialize(2 * n, slots_);
}

auto CoefficientPlaintextEncoder::encode(const std::vector<double>& values,
    uint32_t level, std::size_t degree) const -> fideslib::Plaintext {
  if (values.size() > slots_ || level >= full_params_.size() || degree == 0)
    throw std::invalid_argument("plaintext values, level or degree out of range");
  lbcrypto::Plaintext plaintext;
  {
#ifdef _OPENMP
    struct SerialIdentity {
      int previous = omp_get_max_active_levels();
      SerialIdentity() { omp_set_max_active_levels(0); }
      ~SerialIdentity() { omp_set_max_active_levels(previous); }
    } serial;
#endif
    plaintext = cpu_->MakeCKKSPackedPlaintext(values, degree, level,
                                            coefficient_params_[level], slots_);
  }
  auto& temporary = plaintext->GetElement<lbcrypto::DCRTPoly>();
  lbcrypto::DCRTPoly coefficients(full_params_[level], ::Format::COEFFICIENT, false);
  auto& output = coefficients.GetAllElements();
  for (std::size_t i = 0; i < output.size(); ++i)
    output[i].SetValues(temporary.GetElementAtIndex(i).GetValues(), ::Format::COEFFICIENT);
  temporary = std::move(coefficients);
  auto context_copy = context_;
  auto result = std::make_shared<fideslib::PlaintextImpl>(std::move(context_copy));
  result->cpu = std::make_any<lbcrypto::Plaintext>(std::move(plaintext));
  // Do not use the ordinary loader: the pinned version assumes EVALUATION.
  return result;
}

void load_plaintext(fideslib::CryptoContext<fideslib::DCRTPoly>& context,
                    fideslib::Plaintext& plaintext, int ntt_batch) {
  if (ntt_batch <= 0) throw std::invalid_argument("NTT batch must be positive");
  if (plaintext->loaded) return;
  if (!context->loaded || context->devices.empty())
    throw std::invalid_argument("plaintext upload requires a loaded GPU context");
  const auto& cpu = std::any_cast<const lbcrypto::Plaintext&>(plaintext->cpu);
  const auto& poly = cpu->GetElement<lbcrypto::DCRTPoly>();
  const auto& limbs = poly.GetAllElements();
  FIDESlib::CKKS::RawPlainText raw{};
  raw.originalPlainText = cpu;
  raw.numRes = limbs.size(); raw.N = poly.GetRingDimension(); raw.format = poly.GetFormat();
  raw.Noise = cpu->GetScalingFactor(); raw.NoiseLevel = cpu->GetNoiseScaleDeg();
  raw.slots = cpu->GetSlots();
  raw.sub_0.reserve(limbs.size()); raw.moduli.reserve(limbs.size());
  for (const auto& limb : limbs) {
    const auto& values = limb.GetValues();
    auto& output = raw.sub_0.emplace_back(values.GetLength());
    for (std::size_t i = 0; i < output.size(); ++i) output[i] = values[i].ConvertToInt();
    raw.moduli.push_back(limb.GetModulus().ConvertToInt());
  }
  auto& gpu_context = std::any_cast<FIDESlib::CKKS::Context&>(context->gpu);
  auto gpu = std::make_shared<FIDESlib::CKKS::Plaintext>(gpu_context);
  // Constant plaintext buffers omit NTT scratch. Allocate ordinary limbs
  // (including aux pointers) before loadConstant so the transform can use them.
  if (raw.format == ::Format::COEFFICIENT) gpu->c0.grow(raw.numRes - 1);
  gpu->load(raw);
  if (raw.format == ::Format::COEFFICIENT) gpu->c0.NTT(ntt_batch, true);
  synchronize(); // raw owns the staging vectors; neither loader nor NTT may outlive them.
  plaintext->gpu = context->RegisterDevicePlaintext(std::move(gpu));
  plaintext->loaded = true;
}

auto readback_plaintext(const fideslib::Plaintext& plaintext) -> lbcrypto::DCRTPoly {
  if (!plaintext->loaded) throw std::invalid_argument("plaintext is not loaded");
  auto& cc = plaintext->parent_context;
  auto gpu = std::static_pointer_cast<FIDESlib::CKKS::Plaintext>(cc->GetDevicePlaintext(plaintext->gpu));
  FIDESlib::CKKS::RawPlainText raw{};
  gpu->store(raw); synchronize();
  const auto& cpu = std::any_cast<const lbcrypto::Plaintext&>(plaintext->cpu);
  lbcrypto::DCRTPoly out(cpu->GetElement<lbcrypto::DCRTPoly>().GetParams(), ::Format::EVALUATION, false);
  auto& limbs = out.GetAllElements();
  if (raw.sub_0.size() != limbs.size()) throw std::runtime_error("GPU plaintext limb count differs");
  for (std::size_t i = 0; i < limbs.size(); ++i) {
    lbcrypto::NativeVector values(raw.sub_0[i].size(), limbs[i].GetModulus());
    for (std::size_t j = 0; j < values.GetLength(); ++j) values[j] = raw.sub_0[i][j];
    limbs[i].SetValues(std::move(values), ::Format::EVALUATION);
  }
  return out;
}

}  // namespace fhemamba
