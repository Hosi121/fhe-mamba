#pragma once

#include <fideslib.hpp>
#include <openfhe.h>
#include <any>
#include <memory>
#include <vector>

namespace fhemamba {

// Preserve OpenFHE FFT, rounding and scale handling while deferring its final
// RNS NTT to the GPU. Instances have fixed context/slots and private params.
class CoefficientPlaintextEncoder {
 public:
  using Context = fideslib::CryptoContext<fideslib::DCRTPoly>;
  using Params = lbcrypto::DCRTPoly::Params;
  CoefficientPlaintextEncoder(Context context, uint32_t slots);
  auto encode(const std::vector<double>& values, uint32_t level,
              std::size_t degree = 1) const -> fideslib::Plaintext;

 private:
  Context context_;
  lbcrypto::CryptoContext<lbcrypto::DCRTPoly> cpu_;
  uint32_t slots_;
  std::vector<std::shared_ptr<Params>> full_params_, coefficient_params_;
};

// Internal FIDESlib bridge for the pinned backend. Avoid pass-by-value limb
// copies and, for coefficient-format inputs, apply its existing GPU NTT.
// Returns only after upload/NTT complete, preserving all buffer lifetimes.
inline constexpr int kPlaintextNttBatch = 16;
void load_plaintext(fideslib::CryptoContext<fideslib::DCRTPoly>& context,
                    fideslib::Plaintext& plaintext, int ntt_batch = kPlaintextNttBatch);

// Probe-only readback of the loaded GPU polynomial in ordinary OpenFHE form.
auto readback_plaintext(const fideslib::Plaintext& plaintext) -> lbcrypto::DCRTPoly;

}  // namespace fhemamba
