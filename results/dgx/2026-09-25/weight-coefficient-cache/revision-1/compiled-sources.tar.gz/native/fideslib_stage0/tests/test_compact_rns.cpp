#include "compact_rns.hpp"
#include <cassert>
#include <limits>
#include <random>
#include <vector>

int main() {
  const std::vector<uint64_t> moduli{1152921504606846883ULL, 576460752303423433ULL,
                                    576460752303423389ULL};
  std::mt19937_64 random(31);
  std::vector<int64_t> expected(4096);
  for (auto& word : expected) word = static_cast<int64_t>(random() % (1ULL << 52)) - (1LL << 51);
  expected[0] = 0;
  expected[1] = -1;
  expected[2] = 1;
  expected[3] = static_cast<int64_t>(moduli.back()) - 1;
  expected[4] = -expected[3];
  std::vector<std::vector<uint64_t>> limbs(moduli.size());
  for (std::size_t i = 0; i < moduli.size(); ++i) {
    for (auto word : expected) {
      // Independent modular reference, rather than the expansion under test.
      auto remainder = static_cast<__int128>(word) % moduli[i];
      if (remainder < 0) remainder += moduli[i];
      limbs[i].push_back(static_cast<uint64_t>(remainder));
    }
  }
  auto compress = [&] {
    return fhemamba::compact_rns(limbs.size(), expected.size(),
        [&](auto i) { return moduli[i]; }, [&](auto i, auto j) { return limbs[i][j]; });
  };
  const auto result = compress();
  assert(result && *result == expected);
  for (std::size_t i = 0; i < limbs.size(); ++i)
    for (std::size_t j = 0; j < expected.size(); ++j)
      assert(fhemamba::expand_signed_coefficient((*result)[j], moduli[i]) == limbs[i][j]);
  // A mismatching residue at the very last word must reject the entire entry.
  limbs.back().back() ^= 1;
  assert(!compress());
  limbs.back().back() ^= 1;
  limbs[0][0] = moduli[0];
  assert(!compress());
  const auto constant = [](auto, auto) { return uint64_t{0}; };
  assert(!fhemamba::compact_rns(0, 1, [](auto) { return uint64_t{17}; }, constant));
  assert(!fhemamba::compact_rns(1, 0, [](auto) { return uint64_t{17}; }, constant));
  assert(!fhemamba::compact_rns(1, 1, [](auto) { return uint64_t{1}; }, constant));
  assert(!fhemamba::compact_rns(1, 1, [](auto) { return UINT64_MAX; }, constant));
  // A representative outside another limb's no-division range is unsupported.
  assert(!fhemamba::compact_rns(2, 1, [](auto i) { return uint64_t{i ? 7u : 31u}; },
      [](auto, auto) { return uint64_t{8}; }));
}
