#pragma once

#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <vector>

namespace fhemamba {

// The signed representative must have magnitude strictly below each modulus.
// No floating conversion, rounding or division occurs when expanding a hit.
inline auto expand_signed_coefficient(int64_t value, uint64_t modulus) -> uint64_t {
  return static_cast<uint64_t>(value) + (value < 0 ? modulus : 0);
}

// Recover from the first limb, then verify EVERY limb before admitting data.
// Arbitrary CRT polynomials need not have this compact representation.
template <class Modulus, class Coefficient>
auto compact_rns(std::size_t limbs, std::size_t count, Modulus modulus,
                 Coefficient coefficient) -> std::optional<std::vector<int64_t>> {
  if (!limbs || !count) return std::nullopt;
  uint64_t minimum = std::numeric_limits<int64_t>::max();
  for (std::size_t i = 0; i < limbs; ++i) {
    const auto q = modulus(i);
    if (q < 2 || q > static_cast<uint64_t>(std::numeric_limits<int64_t>::max()))
      return std::nullopt;
    if (q < minimum) minimum = q;
  }
  const uint64_t first = modulus(0);
  std::vector<int64_t> words(count);
  for (std::size_t j = 0; j < count; ++j) {
    const uint64_t word = coefficient(0, j);
    if (word >= first) return std::nullopt;
    const bool negative = word > first / 2;
    const uint64_t magnitude = negative ? first - word : word;
    if (magnitude >= minimum) return std::nullopt;
    words[j] = negative ? -static_cast<int64_t>(magnitude) : static_cast<int64_t>(magnitude);
  }
  for (std::size_t i = 0; i < limbs; ++i) {
    const uint64_t q = modulus(i);
    for (std::size_t j = 0; j < count; ++j)
      if (coefficient(i, j) != expand_signed_coefficient(words[j], q)) return std::nullopt;
  }
  return words;
}

}  // namespace fhemamba
