#include "stage1_mamba2_config.hpp"

#include <functional>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

auto parse(std::vector<std::string> args) -> fhemamba::stage1::Config {
  std::vector<char*> argv;
  argv.reserve(args.size());
  for (auto& arg : args) {
    argv.push_back(arg.data());
  }
  return fhemamba::stage1::parse_args(static_cast<int>(argv.size()), argv.data());
}

void require(bool condition, const char* message) {
  if (!condition) {
    throw std::runtime_error(message);
  }
}

void require_invalid(const std::function<void()>& operation) {
  try {
    operation();
  } catch (const std::invalid_argument&) {
    return;
  }
  throw std::runtime_error("expected invalid_argument");
}

}  // namespace

auto main() -> int {
  const auto defaults = parse({"stage1", "--input", "payload"});
  require(defaults.input == "payload", "input was not parsed");
  require(defaults.process_role == "inline", "unexpected process role default");
  require(defaults.ring_dim == 131072, "unexpected ring dimension default");
  require(defaults.multiplicative_depth == 44, "unexpected depth default");
  require(defaults.pt_cache_gib == 5.0, "unexpected plaintext cache default");
  require(defaults.security == "128-classic", "native security default must be checked");
  require(!defaults.logarithmic_replication, "binary replication must remain opt-in");
  require(!defaults.coefficient_aware_ps, "coefficient-aware PS must remain opt-in");
  require(!defaults.joint_periodic_coefficients, "periodic joint coefficients must remain opt-in");
  require(parse({"stage1", "--input", "payload", "--joint-periodic-coefficients", "true"}).joint_periodic_coefficients,
          "periodic joint coefficient flag was not parsed");
  require(!defaults.joint_subring_encoding, "subring encoding must remain opt-in");
  require(!defaults.fast_plaintext_upload && !defaults.gpu_plaintext_ntt,
          "plaintext acceleration must remain opt-in");
  const auto plaintext = parse({"stage1", "--input", "payload",
                               "--fast-plaintext-upload", "true", "--gpu-plaintext-ntt", "1"});
  require(plaintext.fast_plaintext_upload && plaintext.gpu_plaintext_ntt,
          "plaintext preparation options were not parsed");
  const auto direct = parse({"stage1", "--input", "payload", "--direct-plaintext-upload", "1"});
  require(direct.direct_plaintext_upload, "direct plaintext upload was not parsed");
  require(!defaults.move_plaintext_coefficients, "coefficient moves must remain opt-in");
  const auto moving = parse({"stage1", "--input", "payload",
                             "--move-plaintext-coefficients", "1", "--gpu-plaintext-ntt", "0"});
  require(moving.move_plaintext_coefficients && moving.gpu_plaintext_ntt,
          "coefficient moves must imply GPU NTT regardless of argument order");
  require(!defaults.borrow_plaintext_upload, "borrowed upload must remain opt-in");
  const auto borrowing = parse({"stage1", "--input", "payload",
                                "--borrow-plaintext-upload", "1", "--direct-plaintext-upload", "0"});
  require(borrowing.borrow_plaintext_upload && borrowing.direct_plaintext_upload && !borrowing.gpu_plaintext_ntt,
          "borrowed upload must imply direct upload without changing the encoding policy");
  require(parse({"stage1", "--input", "payload", "--joint-periodic-coefficients", "true",
                 "--joint-subring-encoding", "true"}).joint_subring_encoding,
          "subring encoding flag was not parsed");
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--joint-subring-encoding", "true"});
  });
  require(parse({"stage1", "--input", "payload", "--coefficient-aware-ps", "true"}).coefficient_aware_ps,
          "coefficient-aware PS flag was not parsed");
  require(!defaults.row_normalized_state, "row normalization must remain opt-in");
  const auto rows = parse({"stage1", "--input", "payload",
                           "--normalized-recurrent-state", "true",
                           "--row-normalized-state", "true"});
  require(rows.row_normalized_state, "row normalization flag was not parsed");
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--row-normalized-state", "true"});
  });

  const std::string binary_hash(64, 'a');
  const auto provenance = parse({"stage1", "--input", "payload",
                                 "--binary-sha256", binary_hash});
  require(provenance.binary_sha256 == binary_hash, "binary hash was not parsed");

  const auto server = parse({
      "stage1",
      "--input-chain",
      "chain",
      "--process-role",
      "server-eval",
      "--handoff-dir",
      "handoff",
      "--output-json",
      "result.json",
  });
  require(server.input_chain == "chain", "chain input was not parsed");
  require(server.process_role == "server-eval", "server role was not parsed");

  const auto explicit_false =
      parse({"stage1", "--input", "payload", "--debug-decrypt", "false"});
  require(!explicit_false.debug_decrypt, "false boolean was not parsed");
  const auto state_range_debug = parse(
      {"stage1", "--input", "payload",
       "--debug-normalized-state-bootstrap-range", "true"});
  require(state_range_debug.debug_normalized_state_bootstrap_range,
          "normalized-state bootstrap range debug flag was not parsed");
  const auto recurrence_debug = parse(
      {"stage1", "--input-chain", "chain", "--tokens", "3",
       "--autoregressive-client-loop", "true", "--debug-recurrence-token", "2",
       "--debug-recurrence-layer", "4"});
  require(recurrence_debug.debug_recurrence_token == 2,
          "recurrence debug token was not parsed");
  require(recurrence_debug.debug_recurrence_layer == 4,
          "recurrence debug layer was not parsed");
  const auto true_bsgs = parse({"stage1", "--input", "payload", "--bsgs-replicas",
                                "auto", "--replicated-true-bsgs", "true",
                                "--logarithmic-replication", "true",
                                "--fused-replicated-linear-transform", "true",
                                "--fused-replicated-linear-transform-scope", "out-proj",
                                "--fideslib-sync-profile", "bootstrap-lifetime",
                                "--interleaved-replicated-projection", "true",
                                "--replicated-state-blocks", "true",
                                "--shared-head-expansion", "true",
                                "--projection-late-level", "true"});
  require(true_bsgs.replicated_true_bsgs, "true replicated BSGS was not parsed");
  require(true_bsgs.logarithmic_replication, "binary replication was not parsed");
  require(true_bsgs.fused_replicated_linear_transform,
          "fused replicated linear transform was not parsed");
  require(true_bsgs.fused_replicated_linear_transform_scope == "out-proj",
          "fused replicated linear transform scope was not parsed");
  require(true_bsgs.fideslib_sync_profile == "bootstrap-lifetime",
          "FIDESlib sync profile was not parsed");
  require(true_bsgs.interleaved_replicated_projection,
          "interleaved replicated projection was not parsed");
  require(true_bsgs.replicated_state_blocks,
          "replicated state blocks mode was not parsed");
  require(true_bsgs.shared_head_expansion,
          "shared head expansion mode was not parsed");
  require(true_bsgs.projection_late_level,
          "projection late-level mode was not parsed");
  const auto consumption_plain =
      parse({"stage1", "--input", "payload", "--pt-cache-weight-level", "20",
             "--pt-miss-consumption-level", "1", "--state-refresh-interval", "2",
             "--normalized-recurrent-state", "true",
             "--complex-state-pairing", "true",
             "--normalized-state-meta-bts", "true",
             "--meta-bts", "true",
             "--meta-bts-residual-layers", "21,22,23"});
  require(consumption_plain.pt_cache_weight_level == 20,
          "weight plaintext cache level was not parsed");
  require(consumption_plain.pt_miss_consumption_level,
          "consumption-level plaintext mode was not parsed");
  require(consumption_plain.state_refresh_interval == 2,
          "state refresh interval was not parsed");
  require(consumption_plain.normalized_recurrent_state,
          "normalized recurrent state was not parsed");
  require(consumption_plain.complex_state_pairing,
          "complex state pairing was not parsed");
  require(consumption_plain.normalized_state_meta_bts,
          "normalized state Meta-BTS was not parsed");
  require(consumption_plain.meta_bts_residual_layers == std::set<int>({21, 22, 23}),
          "residual Meta-BTS layer set was not parsed");
  require(fhemamba::stage1::should_use_meta_bts(
              consumption_plain, 22, false, false, "t1.L22.residual"),
          "selected residual layer did not enable Meta-BTS");
  require(!fhemamba::stage1::should_use_meta_bts(
              consumption_plain, 20, false, false, "t1.L20.residual"),
          "unselected residual layer enabled Meta-BTS");
  require(fhemamba::stage1::should_use_meta_bts(
              consumption_plain, 20, false, false, "t1.L20.gated_poly_input"),
          "existing gated Meta-BTS policy changed");
  require(fhemamba::stage1::should_use_meta_bts(
              consumption_plain, 20, true, true, "t1.L20.state_post0"),
          "normalized-state Meta-BTS override changed");
  const auto scheduled = parse({"stage1", "--input", "payload"});
  require(fhemamba::stage1::should_use_meta_bts(
              scheduled, 0, false, false, "t0.L00.conv_silu", true),
          "scheduled normalization must protect new transient refreshes");
  require(!fhemamba::stage1::should_use_meta_bts(
              scheduled, 0, true, true, "t1.L00.state_post0", true),
          "scheduled normalization must retain the carried-state policy");

  require_invalid([] { parse({"stage1"}); });
  require_invalid([] {
    parse({"stage1", "--input", "one", "--input-chain", "two"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--process-role", "server-eval"});
  });
  require_invalid([] {
    parse({
        "stage1",
        "--input",
        "payload",
        "--process-role",
        "server-eval",
        "--handoff-dir",
        "handoff",
        "--output-json",
        "result.json",
        "--debug-decrypt",
        "1",
    });
  });
  require_invalid([] {
    parse({
        "stage1",
        "--input",
        "payload",
        "--process-role",
        "server-eval",
        "--handoff-dir",
        "handoff",
        "--output-json",
        "result.json",
        "--debug-normalized-state-bootstrap-range",
        "1",
    });
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--ring-dim", "65535"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--tokens", "4junk"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--tolerance", "nan"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--debug-decrypt", "yes"});
  });
  require_invalid([] {
    parse({"stage1", "--input-chain", "chain", "--tokens", "3",
           "--autoregressive-client-loop", "true", "--debug-recurrence-token", "2"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--tokens", "3",
           "--debug-recurrence-token", "2", "--debug-recurrence-layer", "4"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--bsgs-replicas", "2junk"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--pt-cache-weight-level", "44"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--state-refresh-interval", "-1"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--meta-bts-residual-layers", "-1"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--normalized-state-meta-bts",
           "true"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--replicated-true-bsgs", "1"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload",
           "--fused-replicated-linear-transform", "1"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload",
           "--fused-replicated-linear-transform-scope", "input"});
  });
  require_invalid([] {
    parse({"stage1", "--input", "payload", "--binary-sha256", "abc123"});
  });
  require_invalid([] {
    parse({
        "stage1",
        "--input",
        "payload",
        "--process-role",
        "server-eval",
        "--handoff-dir",
        "handoff",
        "--output-json",
        "result.json",
        "--debug-refresh-probes",
        "1",
    });
  });
  require_invalid([] {
    parse({
        "stage1",
        "--input",
        "payload",
        "--tokens",
        "3",
        "--bootstrap-before-token",
        "1",
        "--debug-client-reencrypt-before-token",
        "1",
    });
  });
  return 0;
}
