// Exact compact-cache reconstruction and cold/repeated public-weight timing.
#include "fideslib_plaintext_encoder.hpp"
#include "packed_program.hpp"
#include "stage1_mamba2_plan.hpp"
#include <cuda_runtime_api.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>

using namespace fideslib;
using Clock = std::chrono::steady_clock;
static auto cpu(const Plaintext& p) -> const lbcrypto::Plaintext& {
  return std::any_cast<const lbcrypto::Plaintext&>(p->cpu);
}
static double seconds(Clock::time_point start) {
  return std::chrono::duration<double>(Clock::now() - start).count();
}
static void same(const Plaintext& a, const Plaintext& b) {
  const auto& x = cpu(a); const auto& y = cpu(b);
  if (x->GetElement<lbcrypto::DCRTPoly>() != y->GetElement<lbcrypto::DCRTPoly>() ||
      x->GetScalingFactor() != y->GetScalingFactor() ||
      x->GetScalingFactorInt() != y->GetScalingFactorInt() ||
      a->GetLevel() != b->GetLevel() || x->GetNoiseScaleDeg() != y->GetNoiseScaleDeg() ||
      x->GetSlots() != y->GetSlots() || x->GetCKKSDataType() != y->GetCKKSDataType() ||
      x->GetCKKSPackedValue() != y->GetCKKSPackedValue() || !x->IsEncoded() || !y->IsEncoded())
    throw std::runtime_error("coefficient cache changed CPU RNS or metadata");
}

int main(int argc, char** argv) {
  try {
    if (argc < 2) throw std::invalid_argument("usage: weight_plaintext_probe OUTPUT [--mamba2] [--program FILE]");
    bool mamba2 = false;
    std::string program_path;
    for (int i = 2; i < argc; ++i) {
      const std::string arg = argv[i];
      if (arg == "--mamba2") mamba2 = true;
      else if (arg == "--program" && i + 1 < argc) program_path = argv[++i];
      else throw std::invalid_argument("unknown probe option");
    }
    CCParams<CryptoContextCKKSRNS> params;
    params.SetSecurityLevel(HEStd_NotSet);
    params.SetSecretKeyDist(mamba2 ? SPARSE_TERNARY : UNIFORM_TERNARY);
    params.SetCKKSDataType(mamba2 ? COMPLEX : REAL);
    params.SetRingDim(65536); params.SetBatchSize(32768);
    params.SetMultiplicativeDepth(44); params.SetScalingModSize(59); params.SetFirstModSize(60);
    params.SetScalingTechnique(FLEXIBLEAUTO); params.SetKeySwitchTechnique(HYBRID);
    params.SetNumLargeDigits(3); params.SetDevices({0});
    params.SetPlaintextAutoload(false); params.SetCiphertextAutoload(true);
    auto cc = GenCryptoContext(params);
    for (auto feature : {PKE, KEYSWITCH, LEVELEDSHE}) cc->Enable(feature);
    auto keys = cc->KeyGen(); cc->LoadContext(keys.publicKey);
    if (cudaDeviceSynchronize()) throw std::runtime_error("context synchronization failed");
    const std::size_t entry_bytes = 65536 * sizeof(int64_t);
    int cases = 0, hit_cases = 0, rejected_cases = 0, gpu_cases = 0;
    for (uint32_t slots : {1u, 1024u, 32768u}) {
      fhemamba::CoefficientPlaintextEncoder baseline(cc, slots, true);
      fhemamba::CoefficientPlaintextEncoder cached(cc, slots, true, entry_bytes);
      for (uint32_t level : {0u, 21u, 34u, 44u}) for (int pattern = 0; pattern < 5; ++pattern) {
        cached.clear_cache();
        std::vector<double> values(slots);
        for (uint32_t i = 0; i < slots; ++i)
          values[i] = pattern == 0 ? 0.0 : pattern == 1 ? (i % 3 ? -0.125 : 0.0) :
              pattern == 2 ? std::cos(i * .31 + .1) :
              pattern == 3 ? 1e15 * std::cos(i * .27 + .25) : 1e-8 * std::sin(i + .1);
        auto expected = baseline.encode(values, level);
        auto miss = cached.encode_reusable(values, level, 1);
        same(miss, expected);
        // Poison returned miss storage: retained cache data must be independent.
        auto& word = cpu(miss)->GetElement<lbcrypto::DCRTPoly>().GetAllElements()[0].GetValues()[0];
        word = word.ConvertToInt() ^ 1;
        auto hit = cached.encode_reusable(values, level, 1);
        same(hit, expected);
        if (!cpu(hit)->Encode()) throw std::runtime_error("materialized encoding lost encoded state");
        same(hit, expected);
        const bool admitted = cached.cache_stats.entries == 1;
        if (admitted) {
          if (cached.cache_stats.hits != 1 || cached.cache_stats.bytes != entry_bytes)
            throw std::runtime_error("cache admission or hit accounting failed");
          ++hit_cases;
        } else {
          if (cached.cache_stats.rejected != 2 || cached.cache_stats.bytes != 0)
            throw std::runtime_error("unsupported representation did not fall back");
          ++rejected_cases;
        }
        // Every format and metadata comparison above precedes upload. GPU NTT
        // must also match the ordinary CPU NTT, limb for limb.
        auto expected_ntt = cpu(expected)->GetElement<lbcrypto::DCRTPoly>();
        expected_ntt.SetFormat(::Format::EVALUATION);
        if (fhemamba::load_plaintext(cc, hit, 16, fhemamba::PlaintextUploadMode::Borrowed) !=
              fhemamba::PlaintextUploadMode::Borrowed ||
            fhemamba::readback_plaintext(hit) != expected_ntt)
          throw std::runtime_error("cache GPU readback differs from CPU NTT");
        same(hit, expected);
        ++gpu_cases;
        // Another identity must not evict an admitted entry in this fixed budget.
        auto other = cached.encode_reusable(values, level, 2);
        same(other, expected);
        if (admitted && (cached.cache_stats.entries != 1 || cached.cache_stats.bypasses != 1))
          throw std::runtime_error("fixed admission exceeded its byte budget");
        const auto other_level = level == 0 ? 21u : 0u;
        auto level_expected = baseline.encode(values, other_level);
        auto separate_level = cached.encode_reusable(values, other_level, 1);
        same(separate_level, level_expected);
        if (admitted && (cached.cache_stats.hits != 1 || cached.cache_stats.bypasses != 2))
          throw std::runtime_error("level was omitted from the cache key");
        auto last = cached.encode_reusable(values, level, 1);
        same(last, expected);
        if (admitted && cached.cache_stats.hits != 2) throw std::runtime_error("fixed entry was evicted");
        ++cases;
      }
    }
    // Disabled and sub-entry budgets preserve the normal encoder path.
    int boundary_cases = 0;
    for (std::size_t budget : {std::size_t{0}, entry_bytes - 1}) {
      fhemamba::CoefficientPlaintextEncoder baseline(cc, 32768, true), cached(cc, 32768, true, budget);
      std::vector<double> values(32768, .25);
      auto expected = baseline.encode(values, 21);
      for (int i = 0; i < 2; ++i) { auto value = cached.encode_reusable(values, 21, 7); same(value, expected); }
      if (cached.cache_stats.entries || cached.cache_stats.hits || cached.cache_stats.bytes ||
          cached.cache_stats.bypasses != 2) throw std::runtime_error("cache budget fallback failed");
      ++boundary_cases;
    }
    std::vector<std::vector<double>> diagonals;
    if (!program_path.empty()) {
      std::ifstream input(program_path);
      const auto program = fhemamba::read_packed_program(input, true);
      for (const auto& node : program.nodes) if (node.operation == "linear") {
        const auto columns = program.nodes[node.parents[0]].size;
        auto shape = fhemamba::stage1::resolve_interleaved_replicated_shape(node.size, columns, program.slots, 0);
        shape.logarithmic_replication = true;
        shape.baby_step = std::max(2, static_cast<int>(std::sqrt(shape.per_replica)));
        for (int j = 0; j < std::min(16, shape.per_replica); ++j)
          diagonals.push_back(fhemamba::stage1::replicated_bsgs_pre_mask(
              node.weights(), node.size, columns, j, shape, program.slots, 0.0));
        break;
      }
      if (diagonals.empty()) throw std::runtime_error("no public weight diagonals for benchmark");
    }
    struct Sample { uint32_t level; int block, mode; double seconds; std::size_t hits, misses, rejected; };
    std::vector<Sample> samples;
    for (uint32_t level : {0u, 21u, 34u}) {
      int block = 0;
      for (int mode : {0, 1, 1, 0}) {
        fhemamba::CoefficientPlaintextEncoder encoder(cc, 32768, true, mode ? entry_bytes * diagonals.size() : 0);
        const auto start = Clock::now();
        for (int cycle = 0; cycle < 5; ++cycle) for (std::size_t j = 0; j < diagonals.size(); ++j) {
          // Includes the cold admission/roundtrip cost and every materialization.
          auto p = encoder.encode_reusable(diagonals[j], level, j);
          if (!cpu(p)->IsEncoded()) throw std::runtime_error("unencoded benchmark output");
        }
        const auto duration = seconds(start);
        samples.push_back({level, block++, mode, duration, encoder.cache_stats.hits,
                           encoder.cache_stats.misses, encoder.cache_stats.rejected});
      }
    }
    const bool passed = cases == 60 && hit_cases > 0 && rejected_cases > 0 &&
                        hit_cases + rejected_cases == cases && boundary_cases == 2;
    std::ofstream out(argv[1]);
    if (!out) throw std::runtime_error("cannot open probe report");
    out << std::setprecision(15) << "{\"schema\":\"fhemamba-weight-cache-probe-v1\",\"passed\":"
        << (passed ? "true" : "false") << ",\"cases\":" << cases << ",\"hit_cases\":" << hit_cases
        << ",\"rejected_cases\":" << rejected_cases << ",\"gpu_cases\":" << gpu_cases
        << ",\"boundary_cases\":" << boundary_cases << ",\"exact_rns_and_metadata\":true"
        << ",\"immutable_cache\":true,\"level_key_checked\":true,\"budget_checked\":true"
        << ",\"ckks_data_type\":\"" << (mamba2 ? "complex" : "real") << "\",\"security\":\"not-set\""
        << ",\"diagonals\":" << diagonals.size() << ",\"cycles\":5,\"encoding_samples\":[";
    for (std::size_t i = 0; i < samples.size(); ++i) {
      const auto& s = samples[i]; if (i) out << ',';
      out << "{\"level\":" << s.level << ",\"block\":" << s.block << ",\"mode\":" << s.mode
          << ",\"seconds\":" << s.seconds << ",\"hits\":" << s.hits << ",\"misses\":" << s.misses
          << ",\"rejected\":" << s.rejected << '}';
    }
    out << "]}\n";
    std::cout << "cases=" << cases << " hit_cases=" << hit_cases << " rejected_cases=" << rejected_cases << std::endl;
    return passed ? 0 : 1;
  } catch (const std::exception& e) { std::cerr << e.what() << std::endl; return 2; }
}
