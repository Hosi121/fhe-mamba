"""M1 payload export: everything the native FIDESlib Mamba-2 kernel needs.

One directory per export:
  meta.json            dims, frozen-config poly specs, per-layer squarings,
                       Newton parameters, tensor manifest, test-vector info
  <name>.bin           row-major float32 little-endian arrays (shapes in meta)

Chain exports contain both the exact stateful reference decode and the
identical plaintext polynomial circuit. The kernel uses the latter for FHE
correctness and reports the exact-model gap separately. Approximation quality
requires an evaluation tied to the exported coefficients and head masks; the
historical PPL ladder does not certify a newly exported payload.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path

import torch

from fhemamba.normalization import ScheduledInvSqrt, certify_schedule
from fhemamba.ops import (
    SITE_NAMES,
    ChebPoly,
    Exact,
    HeadMaskedDecay,
    NewtonInvSqrt,
    PolyInitNewton,
    PolyOps,
    RangeRecorder,
    SquaredExpPoly,
    SquaredPoly,
    SquaredPolyInitNewton,
    fit_chebyshev,
    fit_squared_exp,
)
from fhemamba.payload_surrogate import gate_from_spec, public_activation_specs, stabilized_specs
from fhemamba.reference import init_states, model_forward

__all__ = [
    "export_autoregressive_client_payload",
    "export_chain_payload",
    "export_m1_payload",
    "export_state_debug_references",
]
from torch.nn import functional as F  # noqa: N812

FROZEN_DEGREES = {"conv_silu": 96, "gate_silu": 64, "dt_softplus": 64, "decay_exp": 24}
DECAY_HEAD_CLIP = 32.0
RMS_NEWTON = {"init_degree": 47, "iterations": 4, "lo_frac": 0.1, "hi_mul": 2.0}
GATED_NEWTON = {
    "init_degree": 31,
    "iterations": 4,
    "lo_frac": 0.02,
    "hi_mul": 2.0,
    "damping": 0.85,
}
DEFAULT_CAL_TEXT = (
    "Fully homomorphic encryption permits computation on encrypted data. "
    "State space models process long documents with a fixed-size state, "
    "which keeps the encrypted working set bounded during decoding."
)


def _save(out: Path, name: str, tensor: torch.Tensor, manifest: dict) -> None:
    host = tensor.detach().to(device="cpu", dtype=torch.float32)
    arr = host.numpy().astype("<f4", copy=False)
    arr.tofile(out / f"{name}.bin")
    manifest[name] = list(arr.shape)


def _require_native_kernel_compatible(m) -> None:
    """Reject payloads the current FIDESlib decode kernel would silently mis-handle.

    The exporter format is consumed directly by
    native/fideslib_stage0/src/stage1_mamba2_decode_fideslib.cpp. Keep these
    checks aligned with read_m1_payload and the folded-weight circuit there.
    """
    proj_dim = int(m.in_proj.weight.shape[0])
    expected_proj = int(m.intermediate_size + m.conv_dim + m.num_heads)
    if proj_dim != expected_proj:
        msg = "native kernel payload export does not support Mamba-2 d_mlp projections"
        raise ValueError(msg)
    if int(m.n_groups) != 1:
        msg = "native kernel payload export currently requires n_groups == 1"
        raise ValueError(msg)
    if int(m.intermediate_size) != int(m.num_heads * m.head_dim):
        msg = "native kernel payload export requires d_inner == num_heads * head_dim"
        raise ValueError(msg)
    if int(m.conv_dim) != int(m.intermediate_size + 2 * m.ssm_state_size):
        msg = "native kernel payload export requires conv_dim == d_inner + 2 * state_size"
        raise ValueError(msg)
    if m.in_proj.bias is not None or m.out_proj.bias is not None:
        msg = "native kernel payload export does not support in_proj/out_proj bias yet"
        raise ValueError(msg)
    lo, hi = m.time_step_limit
    if float(lo) > 0.0 or not math.isinf(float(hi)):
        msg = "native kernel payload export does not support finite Mamba-2 time_step_limit"
        raise ValueError(msg)


@torch.no_grad()
def _calibrate_payload(
    model, tokenizer, cal_text: str, max_tokens: int | None = None
) -> tuple[dict, list[dict]]:
    """Record polynomial ranges and carried-state bounds on calibration data."""
    cal_ids = tokenizer(cal_text, return_tensors="pt").input_ids
    if max_tokens is not None:
        cal_ids = cal_ids[:, :max_tokens]
    cal_ids = cal_ids.to(model.get_input_embeddings().weight.device)
    recorder = RangeRecorder()
    states = init_states(model)
    state_head_bounds = [
        state.ssm.new_zeros(int(block.mixer.num_heads))
        for block, state in zip(model.backbone.layers, states, strict=True)
    ]
    state_row_bounds = [state.ssm.new_zeros(state.ssm.shape[1:3]) for state in states]
    state_bounds = [state.ssm.new_zeros(()) for state in states]
    fifo_bounds = [state.conv.new_zeros(()) for state in states]
    for token in range(cal_ids.shape[1]):
        model_forward(
            model,
            cal_ids[:, token : token + 1],
            recorder,
            scan="loop",
            output_logits=False,
            states=states,
        )
        for layer, state in enumerate(states):
            state_row_bounds[layer].copy_(
                torch.maximum(state_row_bounds[layer], state.ssm.abs().amax(dim=(0, 3)))
            )
            state_head_bounds[layer].copy_(
                torch.maximum(state_head_bounds[layer], state.ssm.abs().amax(dim=(0, 2, 3)))
            )
            state_bounds[layer].copy_(torch.maximum(state_bounds[layer], state.ssm.abs().amax()))
            fifo_bounds[layer].copy_(torch.maximum(fifo_bounds[layer], state.conv.abs().amax()))

    head_values = torch.stack(state_head_bounds).cpu().tolist()
    row_values = torch.stack(state_row_bounds).flatten(1).cpu().tolist()
    state_values = torch.stack(state_bounds).cpu().tolist()
    fifo_values = torch.stack(fifo_bounds).cpu().tolist()
    bounds = [
        {
            "state_abs_max": float(state_max),
            "state_head_abs_max": [float(value) for value in head_maxima],
            "state_row_abs_max": [float(value) for value in row_maxima],
            "fifo_abs_max": float(fifo_max),
            "calibration_tokens": int(cal_ids.shape[1]),
        }
        for head_maxima, row_maxima, state_max, fifo_max in zip(
            head_values, row_values, state_values, fifo_values, strict=True
        )
    ]
    checkpoint_names = {
        "residual": "residual",
        "proj": "proj",
        "conv_silu_out": "conv_silu",
        "dt_out": "dt",
        "y": "y",
        "layer_output": "output",
    }
    ranges = recorder.ranges
    for layer, bound in enumerate(bounds):
        bound["checkpoint_abs_max"] = {
            output_name: max(abs(value) for value in ranges[(layer, recorded_name)])
            for recorded_name, output_name in checkpoint_names.items()
        }
        gated_lo, gated_hi = ranges[(layer, "gated_rms_invsqrt")]
        bound["gated_variance_range"] = [gated_lo, gated_hi]
    return ranges, bounds


@dataclass(frozen=True)
class _TestVectors:
    token_ids: list[int]
    embeddings: torch.Tensor
    layer_inputs: list[torch.Tensor]
    layer_outputs: list[torch.Tensor]
    layer_states: list[torch.Tensor]
    expected_final: torch.Tensor


@dataclass(frozen=True)
class _AutoregressiveTrace:
    prompt_ids: list[int]
    evaluated_ids: list[int]
    generated_ids: list[int]
    embeddings: torch.Tensor
    layer_outputs: list[torch.Tensor]
    layer_states: list[torch.Tensor]
    layer_decays: list[torch.Tensor]
    layer_state_updates: list[torch.Tensor]
    layer_state_decayed: list[torch.Tensor]
    expected_final: torch.Tensor


class _RecurrenceRecordingOps:
    """Delegate nonlinearities while retaining polynomial recurrence terms."""

    _RECURRENCE_NAMES = frozenset({"decay_output", "state_update", "state_decayed"})

    def __init__(self, base) -> None:
        self.base = base if base is not None else Exact()
        self.records: dict[tuple[int, str], list[torch.Tensor]] = {}

    def checkpoint(self, x: torch.Tensor, site: tuple[int, str]) -> torch.Tensor:
        value = self.base.checkpoint(x, site)
        if site[1] in self._RECURRENCE_NAMES:
            sample = value[0, 0] if site[1] == "decay_output" else value[0]
            self.records.setdefault(site, []).append(sample.clone())
        return value

    def silu(self, x: torch.Tensor, site: tuple[int, str]) -> torch.Tensor:
        return self.base.silu(x, site)

    def softplus(self, x: torch.Tensor, site: tuple[int, str]) -> torch.Tensor:
        return self.base.softplus(x, site)

    def exp(self, x: torch.Tensor, site: tuple[int, str]) -> torch.Tensor:
        return self.base.exp(x, site)

    def inv_sqrt(self, x: torch.Tensor, site: tuple[int, str]) -> torch.Tensor:
        return self.base.inv_sqrt(x, site)

    def mamba2_gates(self, z, a_cont, layer, time_step_limit):
        # The base dispatches its own checkpoints. Capture the returned decay
        # without invoking that checkpoint a second time or bypassing a
        # joint-gate override with independent softplus/exp calls.
        write, decay = self.base.mamba2_gates(z, a_cont, layer, time_step_limit)
        self.records.setdefault((layer, "decay_output"), []).append(decay[0, 0].clone())
        return write, decay


@torch.no_grad()
def _collect_test_vectors_from_ids(model, ids: torch.Tensor, ops=None) -> _TestVectors:
    ids = ids.to(model.get_input_embeddings().weight.device)
    embeddings = model.backbone.embeddings(ids)[0]
    states = init_states(model)
    layer_inputs: list[list[torch.Tensor]] = [[] for _ in model.backbone.layers]
    layer_outputs: list[list[torch.Tensor]] = [[] for _ in model.backbone.layers]
    layer_states: list[list[torch.Tensor]] = [[] for _ in model.backbone.layers]
    expected_final = []
    for token in range(ids.shape[1]):
        hidden_states = model_forward(
            model,
            ids[:, token : token + 1],
            ops=ops,
            states=states,
            output_hidden_states=True,
            output_logits=False,
        )["hidden_states"]
        for layer in range(len(model.backbone.layers)):
            layer_input = embeddings[token] if layer == 0 else hidden_states[layer - 1][0, 0]
            layer_inputs[layer].append(layer_input)
            layer_outputs[layer].append(hidden_states[layer][0, 0])
            layer_states[layer].append(states[layer].ssm[0].clone())
        expected_final.append(hidden_states[-1][0, 0])
    return _TestVectors(
        token_ids=[int(value) for value in ids[0].tolist()],
        embeddings=embeddings,
        layer_inputs=[torch.stack(values) for values in layer_inputs],
        layer_outputs=[torch.stack(values) for values in layer_outputs],
        layer_states=[torch.stack(values) for values in layer_states],
        expected_final=torch.stack(expected_final),
    )


@torch.no_grad()
def _collect_test_vectors(
    model, tokenizer, prompt: str, n_test_tokens: int, ops=None
) -> _TestVectors:
    ids = tokenizer(prompt, return_tensors="pt").input_ids[:, :n_test_tokens]
    return _collect_test_vectors_from_ids(model, ids, ops=ops)


@torch.no_grad()
def _collect_autoregressive_trace(
    model,
    tokenizer,
    prompt: str,
    prompt_tokens: int,
    generate_tokens: int,
    ops=None,
    record_recurrence: bool = False,
    record_layer_details: bool = True,
) -> _AutoregressiveTrace:
    if prompt_tokens < 1 or generate_tokens < 1:
        raise ValueError("autoregressive prompt/generate token counts must be positive")
    tokenized = tokenizer(prompt, return_tensors="pt").input_ids
    if tokenized.shape[1] < prompt_tokens:
        raise ValueError("prompt does not contain enough tokens for autoregressive export")
    device = model.get_input_embeddings().weight.device
    prompt_ids = [int(value) for value in tokenized[0, :prompt_tokens].tolist()]
    evaluated_ids = list(prompt_ids)
    generated_ids: list[int] = []
    expected_final: list[torch.Tensor] = []
    layer_outputs: list[list[torch.Tensor]] = [[] for _ in model.backbone.layers]
    layer_states: list[list[torch.Tensor]] = [[] for _ in model.backbone.layers]
    recurrence_ops = _RecurrenceRecordingOps(ops) if record_recurrence else None
    active_ops = recurrence_ops if recurrence_ops is not None else ops
    states = init_states(model)
    logits = None

    def record_step(output) -> None:
        hidden_states = output["hidden_states"]
        if record_layer_details:
            for layer in range(len(model.backbone.layers)):
                layer_outputs[layer].append(hidden_states[layer][0, 0])
                layer_states[layer].append(states[layer].ssm[0].clone())
        expected_final.append(hidden_states[-1][0, 0])

    for token_id in prompt_ids:
        step = torch.tensor([[token_id]], device=device)
        output = model_forward(
            model,
            step,
            ops=active_ops,
            states=states,
            output_hidden_states=True,
        )
        record_step(output)
        logits = output["logits"][0, -1]
    for generated_index in range(generate_tokens):
        if logits is None or not torch.isfinite(logits).all():
            raise ValueError("autoregressive export produced non-finite client logits")
        token_id = int(logits.argmax())
        generated_ids.append(token_id)
        if generated_index + 1 == generate_tokens:
            break
        evaluated_ids.append(token_id)
        step = torch.tensor([[token_id]], device=device)
        output = model_forward(
            model,
            step,
            ops=active_ops,
            states=states,
            output_hidden_states=True,
        )
        record_step(output)
        logits = output["logits"][0, -1]
    evaluated = torch.tensor([evaluated_ids], device=device)
    embeddings = model.backbone.embeddings(evaluated)[0]
    final_tensor = torch.stack(expected_final)
    if not torch.isfinite(embeddings).all() or not torch.isfinite(final_tensor).all():
        raise ValueError("autoregressive export produced non-finite embeddings/hidden states")

    def recurrence_values(name: str) -> list[torch.Tensor]:
        if recurrence_ops is None:
            return []
        return [
            torch.stack(recurrence_ops.records[(layer, name)])
            for layer in range(len(model.backbone.layers))
        ]

    return _AutoregressiveTrace(
        prompt_ids=prompt_ids,
        evaluated_ids=evaluated_ids,
        generated_ids=generated_ids,
        embeddings=embeddings,
        layer_outputs=[torch.stack(values) for values in layer_outputs]
        if record_layer_details
        else [],
        layer_states=[torch.stack(values) for values in layer_states]
        if record_layer_details
        else [],
        layer_decays=recurrence_values("decay_output"),
        layer_state_updates=recurrence_values("state_update"),
        layer_state_decayed=recurrence_values("state_decayed"),
        expected_final=final_tensor,
    )


def _poly_from_export_spec(spec: dict):
    if spec["kind"] == "scaled-goldschmidt-invsqrt-v1":
        return ScheduledInvSqrt.from_recipe(spec)
    coeffs = spec.get("coeffs", [])
    base = ChebPoly(tuple(coeffs), float(spec["lo"]), float(spec["hi"])) if coeffs else None
    kind = spec["kind"]
    if kind == "cheb":
        return base
    if kind == "cheb-squared":
        return SquaredPoly(base)
    if kind == "cheb-resquared":
        operation = SquaredExpPoly(base, int(spec["squarings"]))
        if "head_mask" in spec:
            return HeadMaskedDecay(operation, tuple(float(value) for value in spec["head_mask"]))
        return operation
    if kind == "const-newton":
        guess = float(spec["guess"])
        if guess <= 0.0:
            raise ValueError("const-newton guess must be positive")
        return NewtonInvSqrt(
            lo=0.0,
            hi=1.0 / (4.0 * guess * guess),
            iterations=int(spec["iterations"]),
        )
    if kind == "poly-newton":
        return PolyInitNewton(base, int(spec["iterations"]))
    if kind == "sq-poly-newton":
        return SquaredPolyInitNewton(base, int(spec["iterations"]), float(spec["damping"]))
    msg = f"unsupported exported polynomial kind: {kind}"
    raise ValueError(msg)


def _poly_ops_from_export(out: Path, n_layers: int, final_norm_spec: dict | None = None) -> PolyOps:
    layer_polys = {}
    joint_gates = {}
    for layer in range(n_layers):
        meta = json.loads((out / f"layer_{layer:02d}" / "meta.json").read_text())
        for name, spec in meta["polys"].items():
            layer_polys[(layer, name)] = _poly_from_export_spec(spec)
        if "joint_gates" in meta:
            joint_gates[layer] = gate_from_spec(meta["joint_gates"])
    if final_norm_spec is None and (out / "chain.json").is_file():
        final_norm_spec = json.loads((out / "chain.json").read_text()).get("final_norm_poly")
    # Older payloads have no dedicated final fit; retain their exact circuit.
    layer_polys[(n_layers, "rms_invsqrt")] = (
        _poly_from_export_spec(final_norm_spec)
        if final_norm_spec is not None
        else layer_polys[(n_layers - 1, "rms_invsqrt")]
    )
    return PolyOps(
        polys={},
        enabled=frozenset(SITE_NAMES),
        layer_polys=layer_polys,
        joint_gates=joint_gates,
    )


@torch.no_grad()
def export_state_debug_references(model, chain_dir: str | Path, tokens: int | None = None) -> Path:
    """Refresh polynomial layer boundaries, states, and full-chain references."""
    out = Path(chain_dir)
    chain = json.loads((out / "chain.json").read_text())
    n_layers = int(chain["n_layers"])
    if n_layers != len(model.backbone.layers):
        raise ValueError("chain layer count does not match the model")

    token_ids = chain.get("test_token_ids")
    if token_ids is None:
        first_meta = json.loads((out / chain["layer_dirs"][0] / "meta.json").read_text())
        token_ids = first_meta.get("test_token_ids")
    if token_ids is None and "chain_input_embeddings" in chain["tensors"]:
        shape = chain["tensors"]["chain_input_embeddings"]
        if shape != [int(chain["n_test_tokens"]), int(model.config.hidden_size)]:
            raise ValueError("chain_input_embeddings has an incompatible shape")
        count = math.prod(shape)
        inputs = torch.from_file(
            str(out / "chain_input_embeddings.bin"),
            shared=False,
            size=count,
            dtype=torch.float32,
        ).reshape(shape)
        weights = model.get_input_embeddings().weight.detach()
        weight_norms = weights.float().square().sum(dim=1)
        token_ids = []
        for embedding in inputs:
            value = embedding.to(device=weights.device, dtype=torch.float32)
            distances = weight_norms - 2.0 * (weights.float() @ value) + value.square().sum()
            token_id = int(distances.argmin())
            error = float((weights[token_id].float() - value).abs().amax())
            if error > 1e-5:
                raise ValueError(
                    f"chain embedding does not match checkpoint vocabulary (error={error:.3g})"
                )
            token_ids.append(token_id)
    if token_ids is None and isinstance(chain.get("autoregressive"), dict):
        token_ids = chain["autoregressive"].get("prompt_ids")
        if token_ids is not None:
            token_ids = token_ids[: int(chain["n_test_tokens"])]
    if not isinstance(token_ids, list) or len(token_ids) < 1:
        raise ValueError("chain payload has no test_token_ids")
    if len(token_ids) != int(chain["n_test_tokens"]):
        raise ValueError("recovered token count does not match chain n_test_tokens")
    if tokens is not None and (tokens < 1 or tokens > len(token_ids)):
        raise ValueError("tokens must be within the exported chain length")

    reference_ids = token_ids if tokens is None else token_ids[:tokens]
    ids = torch.tensor([reference_ids], dtype=torch.long)
    exact = _collect_test_vectors_from_ids(model, ids)
    poly = _collect_test_vectors_from_ids(
        model,
        ids,
        ops=_poly_ops_from_export(out, n_layers),
    )
    state_note = "test_state_output[_poly] stores post-update recurrent state for debug attribution"
    boundary_note = (
        "test_layer_output_poly stores the polynomial-circuit layer boundary for debug attribution"
    )
    for layer, directory in enumerate(chain["layer_dirs"]):
        layer_dir = out / directory
        meta_path = layer_dir / "meta.json"
        meta = json.loads(meta_path.read_text())
        if meta.get("test_token_ids") not in (None, token_ids):
            raise ValueError(f"test_token_ids mismatch in {layer_dir}")
        meta["test_token_ids"] = token_ids
        _save(
            layer_dir,
            "test_layer_output_poly",
            poly.layer_outputs[layer],
            meta["tensors"],
        )
        _save(layer_dir, "test_state_output", exact.layer_states[layer], meta["tensors"])
        _save(layer_dir, "test_state_output_poly", poly.layer_states[layer], meta["tensors"])
        if boundary_note not in meta["notes"]:
            meta["notes"].append(boundary_note)
        if state_note not in meta["notes"]:
            meta["notes"].append(state_note)
        meta_path.write_text(json.dumps(meta, indent=2))
    if tokens is None:
        _save(out, "chain_expected_final", exact.expected_final, chain["tensors"])
        _save(out, "chain_expected_poly_final", poly.expected_final, chain["tensors"])
        (out / "chain.json").write_text(json.dumps(chain, indent=2))
    return out


@torch.no_grad()
def _export_autoregressive_assets(
    model,
    tokenizer,
    out: Path,
    manifest: dict[str, list[int]],
    prompt: str,
    prompt_tokens: int,
    generate_tokens: int,
    n_layers: int,
    layer_dirs: list[str],
    final_norm_spec: dict | None = None,
) -> dict:
    if prompt_tokens < 1 or generate_tokens < 1:
        raise ValueError("autoregressive prompt/generate token counts must be positive")
    exact_trace = _collect_autoregressive_trace(
        model,
        tokenizer,
        prompt,
        prompt_tokens,
        generate_tokens,
        record_layer_details=False,
    )
    reference_ops = _poly_ops_from_export(out, n_layers, final_norm_spec)
    poly_trace = _collect_autoregressive_trace(
        model,
        tokenizer,
        prompt,
        prompt_tokens,
        generate_tokens,
        ops=reference_ops,
        record_recurrence=True,
    )
    if final_norm_spec is not None and any(
        reference_ops.violations[site][0] for site in ("rms_invsqrt", "gated_rms_invsqrt")
    ):
        raise ValueError(
            "autoregressive normalization reference inputs leave the certified domains"
        )
    if reference_ops.joint_gates and any(value[0] for value in reference_ops.violations.values()):
        raise ValueError("autoregressive reference inputs leave the exported operator domains")
    embedding_weight = model.get_input_embeddings().weight
    output_embeddings = model.get_output_embeddings()
    lm_head_weight = output_embeddings.weight
    weights_tied = embedding_weight.data_ptr() == lm_head_weight.data_ptr()
    _save(out, "client_embedding_w", embedding_weight, manifest)
    if not weights_tied:
        _save(out, "client_lm_head_w", lm_head_weight, manifest)
    if output_embeddings.bias is not None:
        _save(out, "client_lm_head_b", output_embeddings.bias, manifest)
    _save(out, "autoregressive_poly_embeddings", poly_trace.embeddings, manifest)
    _save(
        out,
        "autoregressive_poly_expected_final",
        poly_trace.expected_final,
        manifest,
    )
    _save(
        out,
        "autoregressive_exact_expected_final",
        exact_trace.expected_final,
        manifest,
    )
    if len(layer_dirs) != n_layers:
        raise ValueError("chain layer_dirs does not match n_layers")
    note = "autoregressive polynomial layer/state references support debug attribution"
    for layer, directory in enumerate(layer_dirs):
        layer_dir = out / directory
        meta_path = layer_dir / "meta.json"
        meta = json.loads(meta_path.read_text())
        _save(
            layer_dir,
            "autoregressive_poly_layer_output",
            poly_trace.layer_outputs[layer],
            meta["tensors"],
        )
        _save(
            layer_dir,
            "autoregressive_poly_state_output",
            poly_trace.layer_states[layer],
            meta["tensors"],
        )
        _save(
            layer_dir,
            "autoregressive_poly_decay_output",
            poly_trace.layer_decays[layer],
            meta["tensors"],
        )
        _save(
            layer_dir,
            "autoregressive_poly_state_update",
            poly_trace.layer_state_updates[layer],
            meta["tensors"],
        )
        _save(
            layer_dir,
            "autoregressive_poly_state_decayed",
            poly_trace.layer_state_decayed[layer],
            meta["tensors"],
        )
        if note not in meta["notes"]:
            meta["notes"].append(note)
        meta_path.write_text(json.dumps(meta, indent=2))
    return {
        "protocol": "client-in-loop-greedy-v1",
        "prompt_tokens": prompt_tokens,
        "generate_tokens": generate_tokens,
        "server_evaluations": len(poly_trace.evaluated_ids),
        "prompt_ids": poly_trace.prompt_ids,
        "poly_evaluated_ids": poly_trace.evaluated_ids,
        "poly_generated_ids": poly_trace.generated_ids,
        "exact_evaluated_ids": exact_trace.evaluated_ids,
        "exact_generated_ids": exact_trace.generated_ids,
        "embedding_lm_head_tied": weights_tied,
        "client_lm_head_bias": output_embeddings.bias is not None,
        "operator_domain_violations": reference_ops.violations,
    }


@torch.no_grad()
def export_autoregressive_client_payload(
    model,
    tokenizer,
    chain_dir: str | Path,
    prompt: str = "The capital of France is",
    prompt_tokens: int = 2,
    generate_tokens: int = 4,
) -> Path:
    """Add client-loop generation assets to an existing chain export.

    This avoids repeating calibration and all per-layer exports. Binary assets
    are written first and chain.json is replaced only after every trace passes.
    """
    out = Path(chain_dir)
    chain_path = out / "chain.json"
    chain = json.loads(chain_path.read_text())
    if chain.get("format") not in {"fhemamba-m2-chain-v1", "fhemamba-m2-chain-joint-v1"}:
        raise ValueError("unsupported chain payload format")
    n_layers = int(chain["n_layers"])
    if len(model.backbone.layers) != n_layers:
        raise ValueError("checkpoint layer count does not match chain payload")
    manifest = dict(chain["tensors"])
    chain["autoregressive"] = _export_autoregressive_assets(
        model,
        tokenizer,
        out,
        manifest,
        prompt,
        prompt_tokens,
        generate_tokens,
        n_layers,
        chain["layer_dirs"],
        chain.get("final_norm_poly"),
    )
    chain["tensors"] = manifest
    note = "autoregressive assets support client decrypt/lm_head/argmax/re-encrypt"
    if note not in chain["notes"]:
        chain["notes"].append(note)
    temporary_path = chain_path.with_suffix(".json.tmp")
    temporary_path.write_text(json.dumps(chain, indent=2))
    temporary_path.replace(chain_path)
    return out


@torch.no_grad()
def export_m1_payload(
    model,
    tokenizer,
    out_dir: str | Path,
    layer_index: int = 0,
    n_test_tokens: int = 4,
    cal_text: str | None = None,
    cal_tokens: int | None = 512,
    bound_cal_text: str | None = None,
    bound_cal_tokens: int | None = 512,
    prompt: str = "The capital of France is",
    gated_init_degree: int | None = None,
    gated_newton_iterations: int | None = None,
    _calibration: tuple[dict, list[dict]] | None = None,
    _test_vectors: _TestVectors | None = None,
) -> Path:
    gated_init_degree = (
        GATED_NEWTON["init_degree"] if gated_init_degree is None else gated_init_degree
    )
    gated_newton_iterations = (
        GATED_NEWTON["iterations"] if gated_newton_iterations is None else gated_newton_iterations
    )
    if gated_init_degree < 1 or gated_newton_iterations < 1:
        raise ValueError("gated norm degree and Newton iterations must be positive")
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    block = model.backbone.layers[layer_index]
    m = block.mixer
    _require_native_kernel_compatible(m)
    manifest: dict[str, list[int]] = {}

    # --- weights -----------------------------------------------------------
    _save(out, "in_proj_w", m.in_proj.weight, manifest)
    _save(out, "conv_w", m.conv1d.weight.squeeze(1), manifest)
    conv_b = (
        m.conv1d.bias
        if m.conv1d.bias is not None
        else torch.zeros(
            m.conv1d.weight.shape[0],
            dtype=m.conv1d.weight.dtype,
            device=m.conv1d.weight.device,
        )
    )
    _save(out, "conv_b", conv_b, manifest)
    _save(out, "dt_bias", m.dt_bias, manifest)
    _save(out, "a_log", m.A_log, manifest)
    _save(out, "d_skip", m.D, manifest)
    _save(out, "block_norm_w", block.norm.weight, manifest)
    _save(out, "gated_norm_w", m.norm.weight, manifest)
    _save(out, "out_proj_w", m.out_proj.weight, manifest)

    # --- calibration on real text, poly fits (frozen config) ----------------
    cal_text = cal_text or DEFAULT_CAL_TEXT
    calibration = _calibration or _calibrate_payload(model, tokenizer, cal_text, cal_tokens)
    if (
        _calibration is None
        and bound_cal_text is not None
        and (bound_cal_text != cal_text or bound_cal_tokens != cal_tokens)
    ):
        _, carried_bounds = _calibrate_payload(model, tokenizer, bound_cal_text, bound_cal_tokens)
        calibration = (calibration[0], carried_bounds)
    calibration_ranges, carried_bounds = calibration

    def rng(name: str, margin: float = 0.3) -> tuple[float, float]:
        lo, hi = calibration_ranges[(layer_index, name)]
        pad = margin * (hi - lo)
        return lo - pad, hi + pad

    polys: dict[str, dict] = {}
    lo, hi = rng("conv_silu")
    p = fit_chebyshev(F.silu, lo, hi, FROZEN_DEGREES["conv_silu"])
    polys["conv_silu"] = {"kind": "cheb", "coeffs": list(p.coeffs), "lo": p.lo, "hi": p.hi}
    lo, hi = rng("gate_silu")
    p = fit_chebyshev(F.silu, lo, hi, FROZEN_DEGREES["gate_silu"])
    polys["gate_silu"] = {"kind": "cheb", "coeffs": list(p.coeffs), "lo": p.lo, "hi": p.hi}
    lo, hi = rng("dt_softplus")
    p = fit_chebyshev(lambda t: torch.sqrt(F.softplus(t)), lo, hi, FROZEN_DEGREES["dt_softplus"])
    polys["dt_softplus"] = {
        "kind": "cheb-squared",
        "coeffs": list(p.coeffs),
        "lo": p.lo,
        "hi": p.hi,
    }
    # Legacy surrogate policy: prune heads with extreme A*dt_max to reduce
    # squaring depth. This is NOT a uniform-negligible-decay certificate:
    # because A<0, the maximum decay occurs at dt_min. Keep the historical
    # surrogate explicit until a replacement passes a new model-quality gate.
    _, dt_input_hi = calibration_ranges[(layer_index, "dt_softplus")]
    dt_max = float(F.softplus(torch.tensor(dt_input_hi)))
    reaches = (-torch.exp(m.A_log.detach().float()) * dt_max).tolist()
    decay_head_mask = tuple(0.0 if reach < -DECAY_HEAD_CLIP else 1.0 for reach in reaches)
    kept_reaches = [
        reach for reach, keep in zip(reaches, decay_head_mask, strict=True) if keep > 0.0
    ]
    clipped_lo = min(kept_reaches) if kept_reaches else -1.0
    sq = fit_squared_exp(min(clipped_lo * 1.3, -1e-6), FROZEN_DEGREES["decay_exp"])
    polys["decay_exp"] = {
        "kind": "cheb-resquared",
        "coeffs": list(sq.base.coeffs),
        "lo": sq.base.lo,
        "hi": 0.0,
        "squarings": sq.squarings,
        "head_mask": list(decay_head_mask),
        "head_clip_threshold": DECAY_HEAD_CLIP,
        "head_pruning_policy": "legacy-largest-step-approximation",
        "head_pruning_uniform_bound_claimed": False,
    }
    lo, hi = calibration_ranges[(layer_index, "rms_invsqrt")]
    base = fit_chebyshev(
        torch.rsqrt,
        RMS_NEWTON["lo_frac"] * lo,
        RMS_NEWTON["hi_mul"] * hi,
        RMS_NEWTON["init_degree"],
    )
    polys["rms_invsqrt"] = {
        "kind": "poly-newton",
        "coeffs": list(base.coeffs),
        "lo": base.lo,
        "hi": base.hi,
        "iterations": RMS_NEWTON["iterations"],
        "damping": 0.9,
    }
    lo, hi = calibration_ranges[(layer_index, "gated_rms_invsqrt")]
    gated_base = fit_chebyshev(
        lambda t: t.abs().clamp(min=1e-30).pow(-0.25),
        GATED_NEWTON["lo_frac"] * lo,
        GATED_NEWTON["hi_mul"] * hi,
        gated_init_degree,
    )
    polys["gated_rms_invsqrt"] = {
        "kind": "sq-poly-newton",
        "coeffs": list(gated_base.coeffs),
        "lo": gated_base.lo,
        "hi": gated_base.hi,
        "iterations": gated_newton_iterations,
        "damping": GATED_NEWTON["damping"],
    }
    checkpoint_bounds = carried_bounds[layer_index]["checkpoint_abs_max"]
    checkpoint_bounds["gated_variance"] = 1.0
    checkpoint_bounds["gated_newton"] = 4.0

    # --- test vectors: stateful reference decode through this layer ---------
    test_vectors = _test_vectors or _collect_test_vectors(model, tokenizer, prompt, n_test_tokens)
    _save(out, "test_layer_input", test_vectors.layer_inputs[layer_index], manifest)
    _save(out, "test_layer_output", test_vectors.layer_outputs[layer_index], manifest)
    _save(out, "test_state_output", test_vectors.layer_states[layer_index], manifest)

    meta = {
        "format": "fhemamba-m1-v1",
        "layer_index": layer_index,
        "checkpoint_layer": layer_index,
        "dims": {
            "d_model": model.config.hidden_size,
            "d_inner": m.intermediate_size,
            "num_heads": m.num_heads,
            "head_dim": m.head_dim,
            "state_size": m.ssm_state_size,
            "n_groups": m.n_groups,
            "conv_kernel": m.conv_kernel_size,
            "conv_dim": m.conv_dim,
        },
        "eps": {
            "block_norm": block.norm.variance_epsilon,
            "gated_norm": m.norm.variance_epsilon,
        },
        "time_step_limit": list(m.time_step_limit),
        "polys": polys,
        "carried_bounds": {
            **carried_bounds[layer_index],
            "source": "calibration_text",
        },
        "n_test_tokens": int(test_vectors.embeddings.shape[0]),
        "test_token_ids": test_vectors.token_ids,
        "tensors": manifest,
        "dtype": "float32-le",
        "notes": [
            "test vectors are exact-op reference decode outputs (state carried from zero)",
            "chain export adds test_layer_output_poly for CKKS correctness;"
            " test_layer_output remains the exact-model quality reference",
        ],
    }
    (out / "meta.json").write_text(json.dumps(meta, indent=2))
    return out


def _normalization_specs(model, bundle_path: str | Path) -> tuple[dict, str]:
    """Validate every site before exporting any new payload or reference."""
    contents = Path(bundle_path).read_bytes()
    bundle = json.loads(contents)
    if bundle.get("format") != "fhemamba-normalization-schedules-v1":
        raise ValueError("unsupported normalization bundle format")
    layers = len(model.backbone.layers)
    required = {(i, site) for i in range(layers) for site in ("rms_invsqrt", "gated_rms_invsqrt")}
    required.add((layers, "rms_invsqrt"))
    specs = {}
    for entry in bundle["operators"]:
        site = (entry["layer"], entry["site"])
        if site not in required or site in specs:
            raise ValueError(f"unexpected or duplicate normalization site: {site}")
        schedule = ScheduledInvSqrt.from_recipe(entry["recipe"])
        if not certify_schedule(schedule)["certified"]:
            raise ValueError(f"uncertified normalization schedule: {site}")
        norm = (
            model.backbone.norm_f
            if site[0] == layers
            else model.backbone.layers[site[0]].mixer.norm
            if site[1] == "gated_rms_invsqrt"
            else model.backbone.layers[site[0]].norm
        )
        eps = float(norm.variance_epsilon)
        eps32 = float(torch.tensor(eps, dtype=torch.float32))
        if not schedule.lo <= min(eps, eps32) <= max(eps, eps32) < schedule.hi:
            raise ValueError(f"normalization domain does not cover checkpoint epsilon: {site}")
        specs[site] = schedule.recipe()
    if specs.keys() != required:
        raise ValueError("normalization bundle must cover every block, gated and final norm")
    return specs, hashlib.sha256(contents).hexdigest()


@torch.no_grad()
def export_chain_payload(
    model,
    tokenizer,
    out_dir: str | Path,
    n_test_tokens: int = 2,
    prompt: str = "The capital of France is",
    cal_text: str | None = None,
    cal_tokens: int | None = 512,
    bound_cal_text: str | None = None,
    bound_cal_tokens: int | None = 512,
    autoregressive_prompt_tokens: int = 0,
    autoregressive_generate_tokens: int = 0,
    gated_init_degree: int | None = None,
    gated_newton_iterations: int | None = None,
    normalization_bundle: str | Path | None = None,
    stabilized_gate_bundle: str | Path | None = None,
) -> Path:
    """M2 payload: one layer_XX/ subdir per layer (m1 format) plus chain.json
    with the final norm, per-token embeddings, and end-to-end test vectors."""
    out = Path(out_dir)
    if stabilized_gate_bundle is not None and normalization_bundle is None:
        raise ValueError("stabilized gates require the matching scheduled normalization bundle")
    gates, gates_sha = (
        stabilized_specs(model, stabilized_gate_bundle)
        if stabilized_gate_bundle is not None
        else ({}, None)
    )
    specs, bundle_sha = (
        _normalization_specs(model, normalization_bundle)
        if normalization_bundle is not None
        else ({}, None)
    )
    if normalization_bundle is not None and out.exists():
        raise ValueError("scheduled normalization export requires a new output directory")
    out.mkdir(parents=True, exist_ok=True)
    n_layers = len(model.backbone.layers)
    final_norm_spec = specs.get((n_layers, "rms_invsqrt"))
    cal_text = cal_text or DEFAULT_CAL_TEXT
    calibration = _calibrate_payload(model, tokenizer, cal_text, cal_tokens)
    if bound_cal_text is not None and (
        bound_cal_text != cal_text or bound_cal_tokens != cal_tokens
    ):
        _, carried_bounds = _calibrate_payload(model, tokenizer, bound_cal_text, bound_cal_tokens)
        calibration = (calibration[0], carried_bounds)
    test_vectors = _collect_test_vectors(model, tokenizer, prompt, n_test_tokens)
    for layer in range(n_layers):
        export_m1_payload(
            model,
            tokenizer,
            out / f"layer_{layer:02d}",
            layer_index=layer,
            n_test_tokens=n_test_tokens,
            prompt=prompt,
            gated_init_degree=gated_init_degree,
            gated_newton_iterations=gated_newton_iterations,
            _calibration=calibration,
            _test_vectors=test_vectors,
        )
        if specs:
            meta_path = out / f"layer_{layer:02d}" / "meta.json"
            meta = json.loads(meta_path.read_text())
            for site in ("rms_invsqrt", "gated_rms_invsqrt"):
                meta["polys"][site] = specs[(layer, site)]
            meta["normalization_bundle_sha256"] = bundle_sha
            if gates:
                meta["format"] = "fhemamba-m1-joint-v1"
                meta["joint_gates"] = gates[layer]
                meta["stabilized_gate_bundle_sha256"] = gates_sha
                meta["polys"].update(public_activation_specs(model.backbone.layers[layer]))
                # Legacy fits are retained only as inactive provenance; the
                # versioned joint format prevents old kernels ignoring the hook.
                meta["polys"]["decay_exp"]["head_mask"] = [1.0] * model.backbone.layers[
                    layer
                ].mixer.num_heads
                meta["notes"].append(
                    "joint_gates replaces dt_softplus and decay_exp; all heads retained"
                )
            meta_path.write_text(json.dumps(meta, indent=2))

    # Cryptographic correctness is measured against the identical polynomial
    # circuit evaluated in plaintext. The exact-model vectors remain alongside
    # it for approximation-quality reporting; conflating the two makes an FHE
    # pass impossible whenever the certified surrogate differs by > tolerance.
    reference_ops = _poly_ops_from_export(out, n_layers, final_norm_spec)
    poly_test_vectors = _collect_test_vectors(
        model,
        tokenizer,
        prompt,
        n_test_tokens,
        ops=reference_ops,
    )
    if specs and not all(
        torch.isfinite(value).all()
        for value in (
            poly_test_vectors.expected_final,
            *poly_test_vectors.layer_outputs,
            *poly_test_vectors.layer_states,
        )
    ):
        raise ValueError("scheduled normalization payload has non-finite polynomial references")
    if specs and any(
        reference_ops.violations[site][0] for site in ("rms_invsqrt", "gated_rms_invsqrt")
    ):
        raise ValueError("normalization reference inputs leave the certified domains")
    if gates and any(count[0] for count in reference_ops.violations.values()):
        raise ValueError("stabilized reference inputs leave the declared polynomial domains")
    for layer in range(n_layers):
        layer_dir = out / f"layer_{layer:02d}"
        meta_path = layer_dir / "meta.json"
        meta = json.loads(meta_path.read_text())
        _save(
            layer_dir,
            "test_layer_output_poly",
            poly_test_vectors.layer_outputs[layer],
            meta["tensors"],
        )
        _save(
            layer_dir,
            "test_state_output_poly",
            poly_test_vectors.layer_states[layer],
            meta["tensors"],
        )
        meta["notes"].append(
            "test_layer_output_poly is the plaintext polynomial-circuit correctness reference"
        )
        meta["notes"].append(
            "test_state_output[_poly] stores post-update recurrent state for debug attribution"
        )
        meta_path.write_text(json.dumps(meta, indent=2))

    manifest: dict[str, list[int]] = {}
    _save(out, "final_norm_w", model.backbone.norm_f.weight, manifest)

    _save(out, "chain_input_embeddings", test_vectors.embeddings, manifest)
    _save(out, "chain_expected_final", test_vectors.expected_final, manifest)
    _save(out, "chain_expected_poly_final", poly_test_vectors.expected_final, manifest)

    autoregressive = None
    if autoregressive_prompt_tokens or autoregressive_generate_tokens:
        autoregressive = _export_autoregressive_assets(
            model,
            tokenizer,
            out,
            manifest,
            prompt,
            autoregressive_prompt_tokens,
            autoregressive_generate_tokens,
            n_layers,
            [f"layer_{layer:02d}" for layer in range(n_layers)],
            final_norm_spec,
        )

    chain = {
        "format": "fhemamba-m2-chain-joint-v1" if gates else "fhemamba-m2-chain-v1",
        "n_layers": n_layers,
        "n_test_tokens": int(test_vectors.embeddings.shape[0]),
        "test_token_ids": test_vectors.token_ids,
        "final_norm_eps": model.backbone.norm_f.variance_epsilon,
        "layer_dirs": [f"layer_{layer:02d}" for layer in range(n_layers)],
        "tensors": manifest,
        "dtype": "float32-le",
        "autoregressive": autoregressive,
        "gated_norm": {
            "init_degree": (
                GATED_NEWTON["init_degree"] if gated_init_degree is None else gated_init_degree
            ),
            "newton_iterations": (
                GATED_NEWTON["iterations"]
                if gated_newton_iterations is None
                else gated_newton_iterations
            ),
        },
        "notes": [
            "per-layer dirs are self-contained m1 payloads (per-layer poly fits)",
            "FHE pass criterion: decrypted outputs match chain_expected_poly_final",
            "chain_expected_final remains the exact-model approximation-quality reference",
        ],
    }
    if final_norm_spec is not None:
        chain["final_norm_poly"] = final_norm_spec
        chain["normalization_bundle_sha256"] = bundle_sha
        chain["reference_domain_violations"] = reference_ops.violations
        chain["notes"].append(
            "Scheduled normalization, shared-factor gates and public-envelope SiLU fits; "
            "domain membership and CKKS error require separate validation."
            if gates
            else "Scheduled normalization domains are conditional; other nonlinearities retain "
            "their exported fits. This is not the jointly stabilized gate surrogate."
        )
    if gates:
        chain["stabilized_gate_bundle_sha256"] = gates_sha
    (out / "chain.json").write_text(json.dumps(chain, indent=2))
    return out
