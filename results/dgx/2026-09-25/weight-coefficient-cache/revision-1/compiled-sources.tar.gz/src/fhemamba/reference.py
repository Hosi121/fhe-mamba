"""Lowerable Mamba-1/2 reference and architecture-aware model forward.

Mamba-3's shared mixer formula lives in mamba3.py and uses the same dispatch
and state-allocation boundary. The Mamba-1/2 implementation reads weights directly
off a ``transformers`` ``MambaForCausalLM`` — there is deliberately no
weight-copying or adaptation layer. With ``Exact`` ops and ``scan="loop"`` it
reproduces ``MambaMixer.slow_forward`` (transformers 5.2) exactly, including
the Δ·B·u input term of the selective-scan discretization.

Two scan schedules compute the same recurrence:

    loop     -- token-by-token, bit-identical to the HF slow path; used for
                parity gates.
    chunked  -- Hillis-Steele doubling inside fixed-size chunks plus a serial
                carry across chunks. Same algebra reassociated (fp noise only,
                verified in tests). This is also the schedule we intend to
                lower to CKKS for prefill, so keeping it in the reference makes
                the plaintext model and the encrypted schedule share structure.
"""

from __future__ import annotations

import torch
from torch import Tensor
from torch.nn import functional as F  # noqa: N812

from fhemamba.architectures import LayerState, init_mixer_state, mixer_forward_dispatch
from fhemamba.ops import Exact, Site
from fhemamba.tensor_ops import TensorOps, rms_normalize, ssm_readout

__all__ = [
    "LayerState",
    "chunked_scan",
    "init_states",
    "mixer2_forward",
    "mixer_forward",
    "model_forward",
    "rms_norm_forward",
]


def init_states(model, batch_size: int = 1) -> list:
    """Zero states for every layer (equivalent to an empty prefix)."""
    return [init_mixer_state(block.mixer, batch_size) for block in model.backbone.layers]


def _stateful_conv(mixer, conv_in: Tensor, state: LayerState | None) -> Tensor:
    """Depthwise causal conv; with a state, the left context comes from the
    FIFO instead of zero padding, and the FIFO is advanced."""
    seq_len = conv_in.shape[-1]
    if state is None:
        return mixer.conv1d(conv_in)[..., :seq_len]
    full = torch.cat([state.conv, conv_in], dim=-1)
    out = F.conv1d(
        full,
        mixer.conv1d.weight,
        mixer.conv1d.bias,
        groups=mixer.conv1d.weight.shape[0],
    )
    history = mixer.conv_kernel_size - 1
    state.conv = full[..., seq_len : seq_len + history].clone()
    return out


def rms_norm_forward(norm, x: Tensor, ops, site: Site) -> Tensor:
    return rms_normalize(x, norm.weight, norm.variance_epsilon, TensorOps(ops), site)


def _affine_scan(a: Tensor, b: Tensor) -> tuple[Tensor, Tensor]:
    """Hillis-Steele inclusive scan of affine maps along dim=-2.

    Returns (A, B) with A[t] = prod a_0..t and B[t] = h_t assuming h_{-1} = 0.
    """
    length = a.shape[-2]
    offset = 1
    while offset < length:
        # Prefix positions below offset are already final for this round.
        # Slice instead of materializing full shifted state/identity tensors.
        b = torch.cat(
            [b[..., :offset, :], b[..., offset:, :] + a[..., offset:, :] * b[..., :-offset, :]],
            dim=-2,
        )
        a = torch.cat([a[..., :offset, :], a[..., offset:, :] * a[..., :-offset, :]], dim=-2)
        offset *= 2
    return a, b


def chunked_scan(
    decay: Tensor, update: Tensor, chunk: int = 64, initial: Tensor | None = None
) -> Tensor:
    """All states of h_t = decay_t * h_{t-1} + update_t, h_{-1} = initial or 0.

    decay/update: (batch, channels, T, state) -> states (batch, channels, T, state).
    """
    batch, channels, seq_len, state = decay.shape
    pad = (-seq_len) % chunk
    if pad:
        decay = torch.cat([decay, decay.new_ones(batch, channels, pad, state)], dim=2)
        update = torch.cat([update, update.new_zeros(batch, channels, pad, state)], dim=2)
    n_chunks = decay.shape[2] // chunk
    a = decay.view(batch, channels, n_chunks, chunk, state)
    b = update.view(batch, channels, n_chunks, chunk, state)

    a, b = _affine_scan(a, b)

    # Serial carry across chunks: h[c, t] = b[c, t] + a[c, t] * carry.
    carry = initial if initial is not None else decay.new_zeros(batch, channels, state)
    pieces = []
    for c in range(n_chunks):
        h_c = b[:, :, c] + a[:, :, c] * carry.unsqueeze(2)
        pieces.append(h_c)
        carry = h_c[:, :, -1]
    return torch.cat(pieces, dim=2)[:, :, :seq_len]


def mixer_forward(
    mixer,
    input_states: Tensor,
    ops,
    layer_idx: int,
    scan: str = "loop",
    state: LayerState | None = None,
) -> Tensor:
    """One MambaMixer, matching slow_forward with Exact ops."""
    batch, seq_len, _ = input_states.shape

    projected = mixer.in_proj(input_states).transpose(1, 2)
    hidden_states, gate = projected.chunk(2, dim=1)

    hidden_states = ops.silu(_stateful_conv(mixer, hidden_states, state), (layer_idx, "conv_silu"))

    ssm_parameters = mixer.x_proj(hidden_states.transpose(1, 2))
    time_step, b_sel, c_sel = torch.split(
        ssm_parameters,
        [mixer.time_step_rank, mixer.ssm_state_size, mixer.ssm_state_size],
        dim=-1,
    )
    discrete_time_step = ops.softplus(
        mixer.dt_proj(time_step), (layer_idx, "dt_softplus")
    ).transpose(1, 2)

    a_cont = -torch.exp(mixer.A_log.float())
    discrete_a = ops.exp(
        a_cont[None, :, None, :] * discrete_time_step[:, :, :, None], (layer_idx, "decay_exp")
    )
    discrete_b = discrete_time_step[:, :, :, None] * b_sel[:, None, :, :].float()
    delta_b_u = discrete_b * hidden_states[:, :, :, None].float()

    if scan == "loop":
        ssm_state = (
            state.ssm
            if state is not None
            else torch.zeros(
                (batch, mixer.intermediate_size, mixer.ssm_state_size),
                device=hidden_states.device,
                dtype=hidden_states.dtype,
            )
        )
        outputs = []
        for i in range(seq_len):
            ssm_state = discrete_a[:, :, i, :] * ssm_state + delta_b_u[:, :, i, :]
            outputs.append(torch.matmul(ssm_state, c_sel[:, i, :].unsqueeze(-1))[:, :, 0])
        scan_output = torch.stack(outputs, dim=-1)
        if state is not None:
            state.ssm = ssm_state
    elif scan == "chunked":
        states = chunked_scan(
            discrete_a, delta_b_u, initial=state.ssm if state is not None else None
        )
        scan_output = torch.einsum("bdtn,btn->bdt", states, c_sel)
        if state is not None:
            state.ssm = states[:, :, -1].clone()
    else:
        msg = f"unknown scan schedule: {scan}"
        raise ValueError(msg)

    scan_output = scan_output + hidden_states * mixer.D[None, :, None]
    scan_output = scan_output * ops.silu(gate, (layer_idx, "gate_silu"))
    return mixer.out_proj(scan_output.transpose(1, 2))


def mixer2_forward(
    mixer,
    input_states: Tensor,
    ops,
    layer_idx: int,
    scan: str = "loop",
    state: LayerState | None = None,
) -> Tensor:
    """One Mamba2Mixer (SSD family): scalar decay per head, gated RMSNorm.

    Matches Mamba2Mixer.torch_forward semantics; the sequential loop and the
    streamed chunk scan are the same recurrence reassociated, so agreement with
    HF's chunked SSD algebra is at fp-noise level, not bit-identical.
    """
    batch, seq_len, _ = input_states.shape
    heads = mixer.num_heads
    head_dim = mixer.head_dim
    state_size = mixer.ssm_state_size
    groups = mixer.n_groups

    projected = ops.checkpoint(mixer.in_proj(input_states), (layer_idx, "proj"))
    d_mlp = (
        projected.shape[-1] - 2 * mixer.intermediate_size - 2 * groups * state_size - heads
    ) // 2
    _, _, gate, hidden_bc, dt = projected.split(
        [d_mlp, d_mlp, mixer.intermediate_size, mixer.conv_dim, heads], dim=-1
    )

    hidden_bc = ops.silu(
        _stateful_conv(mixer, hidden_bc.transpose(1, 2), state).transpose(1, 2),
        (layer_idx, "conv_silu"),
    )
    hidden_bc = ops.checkpoint(hidden_bc, (layer_idx, "conv_silu_out"))
    hidden, b_sel, c_sel = torch.split(
        hidden_bc, [mixer.intermediate_size, groups * state_size, groups * state_size], dim=-1
    )

    a_cont = -torch.exp(mixer.A_log.float())  # (heads,)
    dt, decay = ops.mamba2_gates(
        dt + mixer.dt_bias, a_cont, layer_idx, mixer.time_step_limit
    )  # (batch, T, heads)

    x_heads = hidden.reshape(batch, seq_len, heads, head_dim)
    rep = heads // groups
    b_grouped = b_sel.reshape(batch, seq_len, groups, state_size)
    c_grouped = c_sel.reshape(batch, seq_len, groups, state_size)
    if groups == 1:
        # The native payload path requires one group. Keep its B/C expansion as
        # a broadcast view instead of copying both tensors for every head.
        b_heads = b_grouped.expand(batch, seq_len, heads, state_size)
        c_heads = c_grouped.expand(batch, seq_len, heads, state_size)
    else:
        b_heads = b_grouped.repeat_interleave(rep, dim=2)
        c_heads = c_grouped.repeat_interleave(rep, dim=2)
    dt_x = dt[..., None] * x_heads  # Δ·x, (batch, T, heads, head_dim)

    if scan == "loop":
        ssm_state = (
            state.ssm
            if state is not None
            else input_states.new_zeros(batch, heads, head_dim, state_size)
        )
        outputs = []
        for t in range(seq_len):
            update = dt_x[:, t, :, :, None] * b_heads[:, t, :, None, :]
            update = ops.checkpoint(update, (layer_idx, "state_update"))
            decayed = decay[:, t, :, None, None] * ssm_state
            decayed = ops.checkpoint(decayed, (layer_idx, "state_decayed"))
            ssm_state = decayed + update
            outputs.append(ssm_readout(ssm_state, c_heads[:, t], TensorOps(ops)))
        y = torch.stack(outputs, dim=1)  # (batch, T, heads, head_dim)
        if state is not None:
            state.ssm = ssm_state
    elif scan == "chunked":
        # Streamed chunks keep peak memory at one (heads, head_dim, chunk, state)
        # block instead of materializing all T states at once.
        chunk = 64
        carry = (
            state.ssm
            if state is not None
            else input_states.new_zeros(batch, heads, head_dim, state_size)
        )
        pieces = []
        for start in range(0, seq_len, chunk):
            end = min(start + chunk, seq_len)
            # Decay is scalar per head. _affine_scan preserves this compact
            # shape and broadcasts it against the full state update tensor.
            a_c = decay[:, start:end].permute(0, 2, 1)[:, :, None, :, None]
            u_c = (dt_x[:, start:end, :, :, None] * b_heads[:, start:end, :, None, :]).permute(
                0, 2, 3, 1, 4
            )
            a_s, b_s = _affine_scan(a_c, u_c)
            states = b_s + a_s * carry[:, :, :, None, :]
            pieces.append(torch.einsum("bhpln,blhn->blhp", states, c_heads[:, start:end]))
            carry = states[:, :, :, -1]
        y = torch.cat(pieces, dim=1)
        if state is not None:
            state.ssm = carry.clone()
    else:
        msg = f"unknown scan schedule: {scan}"
        raise ValueError(msg)

    y = y + mixer.D[None, None, :, None] * x_heads
    y = y.reshape(batch, seq_len, -1)

    gated = y * ops.silu(gate, (layer_idx, "gate_silu"))
    gated = ops.checkpoint(gated, (layer_idx, "y"))
    variance = gated.pow(2).mean(-1, keepdim=True)
    y = mixer.norm.weight * (
        gated
        * ops.inv_sqrt(variance + mixer.norm.variance_epsilon, (layer_idx, "gated_rms_invsqrt"))
    )
    return mixer.out_proj(y)


def _mixer_dispatch(mixer):
    return mixer_forward_dispatch(mixer)


@torch.no_grad()
def model_forward(
    model,
    input_ids: Tensor,
    ops=None,
    scan: str = "loop",
    output_hidden_states: bool = False,
    states: list[LayerState] | None = None,
    output_logits: bool = True,
) -> dict[str, object]:
    """Full causal-LM forward. Hidden-state list matches HF ordering:
    one entry per block output, then the final norm output. With ``states``
    (from ``init_states``), the call consumes and advances per-layer recurrent
    state, which is the prefill/decode schedule of the interactive protocol.
    Calibration and diagnostic callers can disable the expensive vocabulary
    projection with ``output_logits=False``."""
    ops = ops if ops is not None else Exact()
    backbone = model.backbone
    hidden = backbone.embeddings(input_ids)
    collected: list[Tensor] = []
    for idx, block in enumerate(backbone.layers):
        residual = ops.checkpoint(hidden, (idx, "residual"))
        normed = rms_norm_forward(block.norm, hidden, ops, (idx, "rms_invsqrt"))
        forward_fn = _mixer_dispatch(block.mixer)
        layer_state = states[idx] if states is not None else None
        hidden = residual + forward_fn(block.mixer, normed, ops, idx, scan=scan, state=layer_state)
        hidden = ops.checkpoint(hidden, (idx, "layer_output"))
        if output_hidden_states:
            collected.append(hidden)
    n_layers = len(backbone.layers)
    final = rms_norm_forward(backbone.norm_f, hidden, ops, (n_layers, "rms_invsqrt"))
    if output_hidden_states:
        collected.append(final)
    out: dict[str, object] = {}
    if output_logits:
        out["logits"] = model.lm_head(final)
    if output_hidden_states:
        out["hidden_states"] = collected
    return out
