"""Serial build/probe controller with an atomic completion hook."""
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/home/kataiwa/fhemamba/s2c-first-20260925')
env = dict(os.environ)
env['PATH'] = '/usr/local/cuda-13.0/bin:' + env['PATH']
env['LD_LIBRARY_PATH'] = '/home/kataiwa/fhe-deps/openfhe-fides/lib:/usr/local/cuda-13.0/lib64'
env['OMP_NUM_THREADS'] = '4'


def write(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2) + '\n')
    temp.replace(path)


def run(name, command, timeout=600):
    directory = root / name
    directory.mkdir(exist_ok=True)
    start = time.time()
    with (directory / 'run.log').open('w') as log:
        p = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT,
                           timeout=timeout, check=False)
    record = {'command': command, 'exit_code': p.returncode, 'started_at_unix': start,
              'wall_seconds': time.time() - start}
    write(directory / 'run.json', record)
    return p.returncode


status = {'started_at_unix': time.time(), 'state': 'running'}
write(root / 'probe-status.json', status)
try:
    while not (root / 'build-completion.json').exists():
        time.sleep(5)
    build = json.loads((root / 'build-completion.json').read_text())
    if build['exit_code']:
        raise RuntimeError('backend build failed')
    commands = [
        ['cmake', '-S', str(root / 'probe'), '-B', str(root / 'probe-build'),
         '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_CXX_COMPILER=/usr/bin/g++',
         f'-Dfideslib_DIR={root}/install/share/fideslib/cmake'],
        ['cmake', '--build', str(root / 'probe-build'), '-j', '4'],
    ]
    for i, command in enumerate(commands):
        if run(f'probe-build-{i}', command):
            raise RuntimeError('probe build failed')
    for mode in ['baseline', 's2c']:
        name = f'initial-{mode}'
        command = ['taskset', '-c', '15-19', str(root / 'probe-build/refresh_probe'),
                   mode, '36', '3', '0', str(root / name / 'native.json')]
        if run(name, command):
            raise RuntimeError(f'{name} failed')
    status['state'] = 'completed'
except Exception as e:
    status['state'] = 'failed'
    status['error'] = str(e)
finally:
    status['finished_at_unix'] = time.time()
    write(root / 'probe-status.json', status)
