from pathlib import Path

root = Path(__file__).parent / "fides-candidate"


def replace(path, before, after, count=1):
    p = root / path
    s = p.read_text()
    prefix = ""
    if path == "src/CKKS/Bootstrap.cu":
        position = s.index("void FIDESlib::CKKS::Bootstrap(Ciphertext&")
        prefix, s = s[:position], s[position:]
    assert s.count(before) == count, (path, before, s.count(before))
    p.write_text(prefix + s.replace(before, after))


replace("api/CryptoContext.cpp", '#include "CryptoContext.hpp"',
        '#include "CryptoContext.hpp"\n#include "CKKS/BootstrapPrecomputation.cuh"')
replace("api/CryptoContext.hpp", "uint32_t slots, uint32_t correctionFactor);",
        "uint32_t slots, uint32_t correctionFactor, bool slotsToCoeffsFirst = false);")
replace("api/CryptoContext.hpp", "std::vector<uint32_t> slots_bootstrap;",
        "std::vector<uint32_t> slots_bootstrap;\n\tstd::vector<uint32_t> s2c_first_slots;")
replace("api/CryptoContext.cpp", "uint32_t slots, uint32_t correctionFactor) {",
        "uint32_t slots, uint32_t correctionFactor, bool slotsToCoeffsFirst) {")
replace("api/CryptoContext.cpp", "\tcontext->EvalBootstrapSetup(levelBudget, std::move(dim1), slots, correctionFactor, true, modall);", """
	if (slotsToCoeffsFirst) {
		const auto cp = std::dynamic_pointer_cast<lbcrypto::CryptoParametersCKKSRNS>(context->GetCryptoParameters());
		if (context->GetCKKSDataType() != lbcrypto::REAL || slots != context->GetRingDimension() / 2 ||
		    cp->GetScalingTechnique() != lbcrypto::FLEXIBLEAUTO || levelBudget != std::vector<uint32_t>{4, 4})
			OPENFHE_THROW("Experimental S2C-first requires full real packing, FLEXIBLEAUTO and budget [4,4]");
		const int l0 = cp->GetElementParams()->GetParams().size();
		// The pinned OpenFHE fork uses this override only to choose lDec.
		// lDec = L0 - (modall + encBudget + decBudget) = 2, as in v1.5 StC-first.
		modall = l0 - levelBudget[0] - levelBudget[1] - 2;
		if (modall < 0) OPENFHE_THROW("Insufficient modulus chain for S2C-first");
		this->s2c_first_slots.push_back(slots);
	}
	context->EvalBootstrapSetup(levelBudget, std::move(dim1), slots, correctionFactor, true, modall);""")
replace("api/CryptoContext.cpp", "\tif (this->devices.empty()) {\n\t\tcontext->EvalBootstrapSetup", "\tif (this->devices.empty()) {\n\t\tif (slotsToCoeffsFirst) OPENFHE_THROW(\"S2C-first prototype requires GPU\");\n\t\tcontext->EvalBootstrapSetup")
replace("api/CryptoContext.cpp", "\t\tFIDESlib::CKKS::AddBootstrapPrecomputation(pkImpl, slot, c);", """
		FIDESlib::CKKS::AddBootstrapPrecomputation(pkImpl, slot, c);
		c->GetBootPrecomputation(slot).slotsToCoeffsFirst =
		    std::find(s2c_first_slots.begin(), s2c_first_slots.end(), slot) != s2c_first_slots.end();""")
replace("api/CryptoContext.cpp", "\tFIDESlib::CKKS::GenBootstrapKeys(skImpl, slots, this->keyDist == fideslib::SPARSE_ENCAPSULATED);", """
	FIDESlib::CKKS::GenBootstrapKeys(skImpl, slots, this->keyDist == fideslib::SPARSE_ENCAPSULATED);
	if (std::find(s2c_first_slots.begin(), s2c_first_slots.end(), slots) != s2c_first_slots.end()) {
		FIDESlib::CKKS::BootstrapPrecomputation precom;
		FIDESlib::CKKS::GetBootstrapIndexes(skImpl->GetCryptoContext(), slots, &precom);
		const auto offset = precom.ctsOutputRotation;
		if (offset) this->EvalRotateKeyGen(secretKey, {offset, -offset});
	}""")
replace("src/CKKS/BootstrapPrecomputation.cuh", "\tint accumulate_bStep = 4;", "\tint accumulate_bStep = 4;\n\tint ctsOutputRotation = 0;\n\tbool slotsToCoeffsFirst = false;")
replace("src/CKKS/openfhe-interface/RawCiphertext.cu", "\n\t\tif constexpr (AFFINE_LT && MAKE_STC_LT_FRIENDLY) {\n\t\t\tfor (uint32_t s = 0; s < result.StC.size(); s++) {", "\n\t\tresult.ctsOutputRotation = ReduceRotation(acc_offset, slots);\n\t\tif constexpr (AFFINE_LT && MAKE_STC_LT_FRIENDLY) {\n\t\t\tfor (uint32_t s = 0; s < result.StC.size(); s++) {")
replace("src/CKKS/Bootstrap.cu", "\tbool sparse_encaps = cc.GetBootPrecomputation(slots).sparse_encaps;\n\n\t{", """
	bool sparse_encaps = cc.GetBootPrecomputation(slots).sparse_encaps;
	const auto& bp = cc.GetBootPrecomputation(slots);
	if (bp.slotsToCoeffsFirst) {
		if (prescaled || slots != cc.N / 2 || isLT)
			throw std::invalid_argument("Unsupported S2C-first bootstrap input");
		// FIDES levels count remaining primes minus one (opposite to OpenFHE).
		// Four StC stages plus one level for AdjustCiphertext require level >= 5.
		while (ctxt.NoiseLevel > 1) ctxt.rescale();
		if (ctxt.getLevel() < 5)
			throw std::invalid_argument("S2C-first requires five remaining levels");
		ctxt.dropToLevel(5);
		// The stock affine transforms defer the CtS output rotation until StC.
		// Restore each transform's boundary when their order is reversed.
		if (bp.ctsOutputRotation) ctxt.rotate(-bp.ctsOutputRotation);
		EvalCoeffsToSlots(ctxt, slots, true);
		cudaDeviceSynchronize();
	}

	{""")
replace("src/CKKS/Bootstrap.cu", "\tif (cc.N / 2 == slots) {\n\t\taux.conjugate(ctxt);", "\tif (cc.N / 2 == slots && !bp.slotsToCoeffsFirst) {\n\t\taux.conjugate(ctxt);")
replace("src/CKKS/Bootstrap.cu", "\n\t//  std::cout << \"LT\" << std::endl;\n\n\tif (isLT)", """
	if (bp.slotsToCoeffsFirst) {
		if (bp.ctsOutputRotation) ctxt.rotate(bp.ctsOutputRotation);
		multIntScalar(ctxt, uint64_t{1} << correction);
		cudaDeviceSynchronize();
		ctxt.slots = old_slots;
		return;
	}

	//  std::cout << "LT" << std::endl;

	if (isLT)""")
