"""Create a separate, reproducible executor prototype; leave the released path intact."""
from pathlib import Path
import shutil

root = Path(__file__).resolve().parent
repo = root.parent.parent
dst = root / "executor-source"
shutil.copytree(repo / "native/fideslib_stage0", dst / "native/fideslib_stage0", dirs_exist_ok=True)
(dst / "src/fhemamba").mkdir(parents=True, exist_ok=True)
shutil.copy2(repo / "src/fhemamba/_version.py", dst / "src/fhemamba/_version.py")

p = dst / "native/fideslib_stage0/include/packed_depth.hpp"
s = p.read_text().replace("static constexpr int ceiling = 39;", "int ceiling = 39;")
s = s.replace("static constexpr int refreshed = 22;", "int refreshed = 22;")
s = s.replace("plan_packed_depth(const PackedProgram& program)",
              "plan_packed_depth(const PackedProgram& program, int ceiling = 39, int refreshed = 22)")
s = s.replace("  PackedDepthPlan plan;", "  PackedDepthPlan plan;\n  plan.ceiling = ceiling;\n  plan.refreshed = refreshed;")
p.write_text(s)

p = dst / "native/fideslib_stage0/src/packed_fideslib.cpp"
s = p.read_text().replace("  bool frontier_refresh = false;",
                         "  bool frontier_refresh = false;\n  bool s2c_first = false;", 1)
s = s.replace("  int slots;", "  int slots;\n  // Configured after aggregate initialization to preserve field order.")
s = s.replace("  int bootstrap_passes = 2;", "  int bootstrap_passes = 2;\n  int refresh_ceiling = 39, refreshed_level = 22;", 1)
s = s.replace("fhemamba::plan_packed_depth(program)",
              "fhemamba::plan_packed_depth(program, refresh_ceiling, refreshed_level)")
s = s.replace("> 39", "> refresh_ceiling").replace("<= 39", "<= refresh_ceiling")
s = s.replace("level < 33", "level < refresh_ceiling - 6")
s = s.replace("    bool frontier_refresh = false;", "    bool frontier_refresh = false;\n    bool s2c_first = false;")
s = s.replace('      else if (option == "--frontier-refresh") frontier_refresh = true;',
              '      else if (option == "--frontier-refresh") frontier_refresh = true;\n'
              '      else if (option == "--s2c-first") s2c_first = true;')
s = s.replace('    if (frontier_refresh && !batch_refresh)',
              '    if (s2c_first && !batch_refresh) throw std::invalid_argument("S2C-first requires planned two-pass batch refresh");\n'
              '    if (frontier_refresh && !batch_refresh)')
s = s.replace("cc->EvalBootstrapSetup({4, 4}, {0, 0}, program.slots, 0);",
              "cc->EvalBootstrapSetup({4, 4}, {0, 0}, program.slots, 0, s2c_first);")
s = s.replace("    evaluator.frontier_refresh = frontier_refresh;",
              "    evaluator.frontier_refresh = frontier_refresh;\n"
              "    evaluator.s2c_first = s2c_first;\n"
              "    evaluator.refresh_ceiling = s2c_first ? 35 : 39;\n"
              "    evaluator.refreshed_level = s2c_first ? 18 : 22;")
s = s.replace('           << ",\\\"frontier_deferrals\\\":"',
              '           << ",\\\"s2c_first\\\":" << (s2c_first ? "true" : "false")\n'
              '           << ",\\\"refresh_ceiling\\\":" << evaluator.refresh_ceiling\n'
              '           << ",\\\"refreshed_level\\\":" << evaluator.refreshed_level\n'
              '           << ",\\\"frontier_deferrals\\\":"')
p.write_text(s)
