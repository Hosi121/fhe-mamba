"""Run level-boundary controls, build, then matched encrypted prefixes serially."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/home/kataiwa/fhemamba/s2c-first-20260925')
env = dict(os.environ, OMP_NUM_THREADS='4')
env['PATH'] = '/usr/local/cuda-13.0/bin:' + env['PATH']
env['LD_LIBRARY_PATH'] = '/home/kataiwa/fhe-deps/openfhe-fides/lib:/usr/local/cuda-13.0/lib64'


def write(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2) + '\n')
    temp.replace(path)


def run(name, command, expected=0, timeout=1200):
    directory = root / name
    directory.mkdir()
    start = time.time()
    with (directory / 'run.log').open('w') as log:
        p = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT,
                           timeout=timeout, check=False)
    record = {'command': command, 'exit_code': p.returncode, 'started_at_unix': start,
              'wall_seconds': time.time() - start, 'expected_exit_code': expected}
    write(directory / 'run.json', record)
    if p.returncode != expected:
        raise RuntimeError(f'{name}: exit {p.returncode}, expected {expected}')
    if (directory / 'native.json').exists() and expected == 0:
        result = json.loads((directory / 'native.json').read_text())
        if not result['passed']:
            raise RuntimeError(f'{name}: accuracy failed')
        return result


status = {'started_at_unix': time.time(), 'state': 'running'}
write(root / 'prefix-status.json', status)
try:
    assert json.loads((root / 'probe-status.json').read_text())['state'] == 'completed'
    probe = str(root / 'probe-build/refresh_probe')
    for name, level, expected in [('s2c-level38', 38, 0), ('s2c-level39-rejected', 39, 3),
                                  ('s2c-level8', 8, 0)]:
        run(name, ['taskset', '-c', '15-19', probe, 's2c', str(level), '2', '0',
                   str(root / name / 'native.json')], expected)
    commands = [
        ['cmake', '-S', str(root / 'executor-source/native/fideslib_stage0'),
         '-B', str(root / 'executor-build'), '-DCMAKE_BUILD_TYPE=Release',
         '-DCMAKE_CXX_COMPILER=/usr/bin/g++',
         f'-DCMAKE_PREFIX_PATH={root}/install;/home/kataiwa/fhe-deps/openfhe-fides',
         f'-Dfideslib_DIR={root}/install/share/fideslib/cmake'],
        ['cmake', '--build', str(root / 'executor-build'), '--target', 'packed_fideslib', '-j', '4'],
    ]
    for i, command in enumerate(commands):
        run(f'executor-build-{i}', command)
    binary = root / 'executor-build/packed_fideslib'
    status['binary_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
    payload = Path('/home/kataiwa/fhemamba/mamba3-20260924/lm-layer1')
    flags = ['--planned-refresh', '--batch-refresh', '--inplace-ops', '--gpu-plaintext-ntt',
             '--profile-evaluation', '--naf-rotations', '--reuse-dead-inputs',
             '--direct-plaintext-upload', '--compact-weights', '--move-plaintext-coefficients',
             '--borrow-plaintext-upload', '--bsgs-routing-stages', '--cache-plaintexts',
             '--frontier-refresh', '--client-head', str(payload / 'client_head.f32')]
    for i, candidate in enumerate([False, True, True, False]):
        name = f'prefix-{i}-' + ('s2c' if candidate else 'baseline')
        command = ['taskset', '-c', '15-19', str(binary), str(payload / 'program.txt'),
                   str(root / name / 'native.json'), '.001', '.001'] + flags
        if candidate:
            command += ['--s2c-first']
        result = run(name, command)
        print(name, result['eval_seconds'], flush=True)
    status['state'] = 'completed'
except Exception as e:
    status['state'] = 'failed'
    status['error'] = str(e)
finally:
    status['finished_at_unix'] = time.time()
    write(root / 'prefix-status.json', status)
