// Research-only probe. Explicitly repeats the production two-pass correction.
#include <fideslib.hpp>
#include <cuda_runtime_api.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

using namespace fideslib;
using Ct = Ciphertext<DCRTPoly>;
using Clock = std::chrono::steady_clock;

void sync() {
  const auto e = cudaDeviceSynchronize();
  if (e != cudaSuccess) throw std::runtime_error(cudaGetErrorString(e));
}

double elapsed(Clock::time_point start) {
  return std::chrono::duration<double>(Clock::now() - start).count();
}

int main(int argc, char** argv) {
  if (argc != 6) {
    std::cerr << "refresh_probe baseline|s2c INPUT_LEVEL REPEATS CORRECTION OUTPUT.json\n";
    return 2;
  }
  const bool s2c = std::string(argv[1]) == "s2c";
  if (!s2c && std::string(argv[1]) != "baseline") return 2;
  const int level = std::stoi(argv[2]), repeats = std::stoi(argv[3]);
  const int correction = std::stoi(argv[4]);
  std::ofstream output(argv[5]);
  output << std::setprecision(17);
  try {
    CCParams<CryptoContextCKKSRNS> p;
    p.SetSecretKeyDist(UNIFORM_TERNARY);
    p.SetSecurityLevel(HEStd_NotSet);
    p.SetRingDim(65536);
    p.SetScalingTechnique(FLEXIBLEAUTO);
    p.SetFirstModSize(60);
    p.SetKeySwitchTechnique(HYBRID);
    p.SetNumLargeDigits(3);
    p.SetMultiplicativeDepth(44);
    p.SetScalingModSize(59);
    p.SetBatchSize(32768);
    p.SetCKKSDataType(REAL);
    p.SetDevices({0});
    p.SetPlaintextAutoload(false);
    p.SetCiphertextAutoload(true);
    const auto setup_start = Clock::now();
    auto cc = GenCryptoContext(p);
    for (auto feature : {PKE, KEYSWITCH, LEVELEDSHE, ADVANCEDSHE, FHE}) cc->Enable(feature);
    auto keys = cc->KeyGen();
    cc->EvalMultKeyGen(keys.secretKey);
    cc->EvalBootstrapSetup({4, 4}, {0, 0}, 32768, correction, s2c);
    cc->EvalBootstrapKeyGen(keys.secretKey, 32768);
    cc->LoadContext(keys.publicKey);
    sync();
    output << "{\"mode\":\"" << argv[1] << "\",\"input_level\":" << level
           << ",\"correction_factor_requested\":" << correction
           << ",\"setup_seconds\":" << elapsed(setup_start) << ",\"samples\":[";
    output.flush();
    auto rescale = [&](Ct& value) {
      while (value->GetNoiseScaleDeg() > 1) cc->RescaleInPlace(value);
      sync();
    };
    auto scale = [&](const Ct& input, double scalar) {
      auto value = input->Clone();
      cc->EvalMultInPlace(value, scalar);
      sync();
      return value;
    };
    auto error = [&](const Ct& value, const std::vector<double>& expected) {
      Plaintext decoded;
      auto copy = value->Clone();
      cc->Decrypt(keys.secretKey, copy, &decoded);
      decoded->SetLength(expected.size());
      const auto actual = decoded->GetRealPackedValue();
      if (actual.size() != expected.size()) throw std::runtime_error("decoded size mismatch");
      double maximum = 0;
      for (size_t i = 0; i < expected.size(); ++i) {
        double e = std::abs(actual[i] - expected[i]);
        if (!std::isfinite(e)) throw std::runtime_error("non-finite output");
        maximum = std::max(maximum, e);
      }
      return maximum;
    };
    double maximum = 0;
    for (int repetition = 0; repetition < repeats; ++repetition) {
      std::mt19937_64 rng(1789 + repetition);
      std::uniform_real_distribution<double> uniform(-1., 1.);
      std::vector<double> expected(32768);
      for (int i = 0; i < 32768; ++i) {
        expected[i] = i < 4096 ? .75 : i < 8192 ? -0.875 :
                      i < 12288 ? (i % 2 ? 1. : -1.) :
                      i < 16384 ? uniform(rng) * 1e-6 : uniform(rng);
      }
      auto pt = cc->MakeCKKSPackedPlaintext(expected, 1, level, nullptr, 32768);
      auto input = cc->Encrypt(keys.publicKey, pt);
      sync();
      const double input_error = error(input, expected);
      const auto start = Clock::now();
      auto first = cc->EvalBootstrap(input);
      sync();
      const double first_seconds = elapsed(start);
      auto a = input->Clone(), b = first->Clone();
      rescale(b);
      const auto target = std::max(a->GetLevel(), b->GetLevel());
      for (auto* value : {&a, &b}) {
        while ((*value)->GetLevel() < target) {
          *value = scale(*value, 1.);
          rescale(*value);
        }
      }
      auto residual = cc->EvalSub(a, b);
      residual = scale(residual, 4096.);
      rescale(residual);
      auto second = cc->EvalBootstrap(residual);
      sync();
      auto normalized_first = scale(first, 1.);
      auto scaled_second = scale(second, 1. / 4096.);
      auto out = cc->EvalAdd(normalized_first, scaled_second);
      sync();
      const double total_seconds = elapsed(start);
      const auto two_pass_error = error(out, expected);
      const auto first_error = error(first, expected);
      maximum = std::max(maximum, two_pass_error);
      if (repetition) output << ',';
      output << "{\"repetition\":" << repetition << ",\"input_error\":" << input_error
             << ",\"first_seconds\":" << first_seconds << ",\"two_pass_seconds\":" << total_seconds
             << ",\"first_error\":" << first_error << ",\"two_pass_error\":" << two_pass_error
             << ",\"first_level\":" << first->GetLevel() << ",\"first_degree\":" << first->GetNoiseScaleDeg()
             << ",\"residual_level\":" << residual->GetLevel() << ",\"output_level\":" << out->GetLevel()
             << ",\"output_degree\":" << out->GetNoiseScaleDeg() << '}';
      output.flush();
      std::cerr << "sample " << repetition << " seconds=" << total_seconds << " error=" << two_pass_error << '\n';
    }
    output << "],\"max_error\":" << maximum << ",\"passed\":" << (maximum <= .001 ? "true" : "false") << "}\n";
    return maximum <= .001 ? 0 : 1;
  } catch (const std::exception& e) {
    std::cerr << "probe failed: " << e.what() << '\n';
    return 3;
  }
}
