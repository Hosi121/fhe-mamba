#include "packed_optimization.hpp"
#include "packed_schedule.hpp"
#include "vector_chebyshev.hpp"
#include <cmath>
#include <iostream>

using namespace fhemamba;
using V = std::vector<double>;
static void require(bool ok, const char* message) {
  if (!ok) throw std::runtime_error(message);
}
static double clenshaw(const V& data, double x) {
  double a = 0, b = 0;
  const double u = (2 * x - data[0] - data[1]) / (data[1] - data[0]);
  for (int i = static_cast<int>(data.size()) - 1; i >= 3; --i) {
    const double c = data[i] + 2 * u * a - b; b = a; a = c;
  }
  return data[2] + u * a - b;
}
static auto reference(const PackedProgram& p) -> std::vector<V> {
  std::vector<V> values;
  for (std::size_t i = 0; i < p.nodes.size(); ++i) {
    const auto& n = p.nodes[i];
    for (int parent : n.parents) require(parent >= 0 && parent < static_cast<int>(i), "non-topological parent");
    V out(n.size);
    if (n.operation == "input" || n.operation == "public") out = n.data;
    else if (n.operation == "feedback") out = values[n.parents[0]];  // deterministic client fixture
    else if (n.operation == "add" || n.operation == "mul")
      for (int j = 0; j < n.size; ++j) out[j] = n.operation == "add"
          ? values[n.parents[0]][j] + values[n.parents[1]][j]
          : values[n.parents[0]][j] * values[n.parents[1]][j];
    else if (n.operation == "addp" || n.operation == "mulp")
      for (int j = 0; j < n.size; ++j) out[j] = n.operation == "addp"
          ? values[n.parents[0]][j] + n.data[j] : values[n.parents[0]][j] * n.data[j];
    else if (n.operation == "gather")
      for (int j = 0; j < n.size; ++j) out[j] = values[n.parents[0]][n.data[j]];
    else if (n.operation == "cheb")
      for (int j = 0; j < n.size; ++j) out[j] = clenshaw(n.data, values[n.parents[0]][j]);
    else if (n.operation == "cheb_batch") {
      int offset = 0;
      for (std::size_t k = 0; k < n.polynomials.size(); ++k) {
        const auto& poly = n.polynomials[k];
        for (int j = 0; j < poly.size; ++j) out[offset++] = clenshaw(poly.data, values[n.parents[k]][j]);
      }
    } else if (n.operation == "linear" || n.operation == "linear_ref") {
      const auto& w = n.operation == "linear" ? n : p.nodes[n.data[0]];
      const auto& x = values[n.parents[0]];
      for (int r = 0; r < n.size; ++r)
        for (std::size_t c = 0; c < x.size(); ++c) out[r] += w.weights()[r * x.size() + c] * x[c];
    } else throw std::runtime_error("unsupported reference operation");
    values.push_back(std::move(out));
  }
  std::vector<V> result;
  for (const auto& output : p.outputs) result.push_back(values[output.node]);
  return result;
}
int main() {
  for (int slots : {4, 8, 16}) {
    PackedProgram p{slots, 64, {
      {"input", 2, {}, {.2, -.4}, 2},
      {"cheb", 2, {0}, {-1, 1, .2, .3, -.1, .07}, 2},
      {"mulp", 2, {0}, {.3, -.7}, 2},
      {"cheb", 2, {2}, {-2, 2, -.1, .5, .2, -.03}, 2},
      {"cheb", 2, {3}, {-1, 1, .1, .2, -.1, .03}, 2},
      {"linear", 2, {1}, {1., 2., -1., .5}, 4},
      {"cheb", 2, {0}, {-1, 1, -.2, .1, .03, .01}, 2},
      {"linear_ref", 2, {6}, {5}, 4},
      {"feedback", 2, {7}, {}, 4},
      {"cheb", 2, {8}, {-2, 2, .1, .2, -.1, .03}, 2},
    }, {{4, {}, {}}, {5, {}, {}}, {9, {}, {}}}};
    auto expected = reference(p);
    PackedOptimizationStats stats;
    auto optimized = batch_packed_polynomials(p, stats);
    require(stats.polynomial_batches == 1 && stats.grouped_polynomials >= 2, "independent polynomials not batched");
    require(reference(optimized) == expected, "batching changed outputs");
    require(plan_packed_depth(optimized).live.size() == optimized.nodes.size(), "batch depth missing");
    for (const auto& n : optimized.nodes) if (n.operation == "cheb_batch")
      require(n.size <= slots, "batch exceeds slots");
  }
  // A batch can bring a weight reference before the original weight owner.
  // Rebind the data reference without introducing a false dataflow dependency.
  PackedProgram p{16, 64, {
    {"input", 1, {}, {.25}, 2},
    {"cheb", 1, {0}, {-1, 1, .2, .3}, 2},
    {"linear", 1, {1}, {2.}, 4},
    {"linear_ref", 1, {0}, {2}, 4},
    {"cheb", 1, {3}, {-1, 1, -.2, .4}, 2},
    {"add", 1, {2, 4}, {}, 8},
  }, {{5, {}, {}}}};
  auto expected = reference(p);
  PackedOptimizationStats stats;
  auto optimized = batch_packed_polynomials(std::move(p), stats);
  require(reference(optimized) == expected, "advanced weight reference corrupted weights");
  require(optimized.nodes[1].operation == "linear", "fixture did not advance the weight reference");
  PackedProgram branches{16, 64, {
    {"input", 1, {}, {.2}, 2},
    {"mulp", 1, {0}, {2.}, 2},
    {"input", 1, {}, {.5}, 2},
    {"mul", 1, {1, 1}, {}, 2},
    {"feedback", 1, {3}, {}, 2},
    {"public", 1, {}, {.3}, 2},
    {"add", 1, {4, 5}, {}, 2},
    {"feedback", 1, {6}, {}, 2},
    {"add", 1, {7, 0}, {}, 2},
    {"mulp", 1, {0}, {7.}, 8}, // dead; cannot hold a frontier open
  }, {{0, {}, {}}, {2, {}, {}}, {8, {}, {}}}};
  const auto depth = plan_packed_depth(branches);
  PackedReadySchedule schedule(branches, depth.live);
  require(schedule.ready() == std::set<int>({0, 2}), "incorrect initial frontier");
  schedule.complete(0);
  require(!schedule.final_use(0, 1), "pinned value can be consumed");
  schedule.complete(1);
  require(schedule.final_use(1, 3), "duplicate edges prevent final-use ownership");
  schedule.complete(3);
  require(schedule.releasable(1) && !schedule.releasable(0), "runtime lifetime is incorrect");
  require(schedule.ready() == std::set<int>({2}), "feedback bypassed independent earlier work");
  schedule.complete(2);
  require(schedule.ready() == std::set<int>({4, 5}), "feedback epoch did not advance");
  schedule.complete(5); schedule.complete(4); schedule.complete(6);
  require(schedule.ready() == std::set<int>({7}), "second feedback barrier is incorrect");
  schedule.complete(7); schedule.complete(8);
  require(schedule.empty() && schedule.ready().empty(), "frontier did not finish");
  require(schedule.next_consumer(0) == -1, "completed consumer remains pending");
  std::cout << "polynomial batching preserves domains, dependencies, slots, feedback and weight references\n";
}
