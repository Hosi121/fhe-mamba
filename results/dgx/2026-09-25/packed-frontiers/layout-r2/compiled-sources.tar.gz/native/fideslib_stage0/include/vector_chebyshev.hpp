#pragma once

#include <algorithm>
#include <cmath>
#include <functional>
#include <map>
#include <stdexcept>
#include <vector>

namespace fhemamba {

// Componentwise Chebyshev PS evaluation. Coefficient rows are degree-major;
// each column is an independent lane. Multiple polynomials share the basis.
// Ops owns the slot layout, constant construction and ciphertext lifetime.
template <typename Value, typename Ops>
auto evaluate_vector_chebyshev(const Value& input, int width, int degree,
                               const std::vector<std::vector<double>>& polynomials,
                               Ops& ops, double term_threshold = 0.0) -> std::vector<Value> {
  if (width < 1 || degree < 0 || degree > 4096 || term_threshold < 0)
    throw std::invalid_argument("invalid vector Chebyshev dimensions");
  for (const auto& c : polynomials)
    if (c.empty() || c.size() % width || c.size() / width > static_cast<std::size_t>(degree + 1))
      throw std::invalid_argument("invalid vector Chebyshev coefficients");
  int log = 1;
  while ((1 << log) < degree + 1) ++log;
  const int baby = 1 << ((log + 1) / 2);
  std::map<int, Value> basis{{1, input}};
  std::function<Value(int)> get = [&](int n) -> Value {
    if (const auto found = basis.find(n); found != basis.end()) return found->second;
    auto product = ops.multiply(get((n + 1) / 2), get(n / 2));
    auto doubled = ops.add(product, product);
    auto value = n % 2 == 0 ? ops.scalar_add(doubled, -1.0) : ops.subtract(doubled, input);
    basis.emplace(n, value);
    return value;
  };
  std::function<Value(std::vector<double>)> evaluate = [&](std::vector<double> c) -> Value {
    const int n = static_cast<int>(c.size()) / width - 1;
    if (n < baby) {
      // The packed scalar evaluator already drops these terms. Apply its
      // exact existing threshold per lane; Mamba-2 uses the zero default.
      if (term_threshold)
        for (std::size_t i = width; i < c.size(); ++i)
          if (std::abs(c[i]) < term_threshold) c[i] = 0.0;
      // Sparse coefficient masks lose another log2(slots) bits during the
      // inverse FFT. Normalize a whole public PS block by an exact power of
      // two, then undo it once after accumulation. This keeps tiny nonzero
      // rows representable without changing or thresholding the polynomial.
      double minimum = 1.0;
      for (int i = 0; i <= n; ++i) {
        double maximum = 0.0;
        for (int h = 0; h < width; ++h) maximum = std::max(maximum, std::abs(c[i * width + h]));
        if (maximum > 0.0) minimum = std::min(minimum, maximum);
      }
      const int shift = minimum < 1e-8
          ? static_cast<int>(std::ceil(std::log2(1e-8) - std::log2(minimum))) : 0;
      if (shift > 50) throw std::runtime_error("vector PS block exceeds supported coefficient encoding range");
      if (shift) for (auto& value : c) value = std::ldexp(value, shift);
      std::vector<double> row(c.begin(), c.begin() + width);
      auto result = ops.constant(row);
      for (int i = 1; i <= n; ++i) {
        row.assign(c.begin() + i * width, c.begin() + (i + 1) * width);
        if (std::all_of(row.begin(), row.end(), [](double x) { return x == 0; })) continue;
        result = ops.add(result, ops.coefficient_product(get(i), row));
      }
      return shift ? ops.scale(result, std::ldexp(1.0, -shift)) : result;
    }
    int k = baby;
    while (2 * k - 1 < n) k *= 2;
    std::vector<double> right(c.begin() + k * width, c.end());
    for (std::size_t i = width; i < right.size(); ++i) right[i] *= 2;
    std::vector<double> left(c.begin(), c.begin() + k * width);
    for (int i = k + 1; i <= n; ++i)
      for (int h = 0; h < width; ++h)
        left[(2 * k - i) * width + h] -= c[i * width + h];
    return ops.add(evaluate(left), ops.multiply(get(k), evaluate(right)));
  };
  std::vector<Value> results;
  for (const auto& coefficients : polynomials) results.push_back(evaluate(coefficients));
  return results;
}
}  // namespace fhemamba
