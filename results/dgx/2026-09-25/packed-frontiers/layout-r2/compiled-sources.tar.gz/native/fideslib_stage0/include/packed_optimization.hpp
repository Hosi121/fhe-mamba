#pragma once

#include "packed_depth.hpp"
#include <functional>
#include <map>
#include <numeric>
#include <tuple>

namespace fhemamba {
struct PackedOptimizationStats {
  int polynomial_batches = 0, grouped_polynomials = 0, maximum_batch = 0;
  int original_nodes = 0, optimized_nodes = 0;
};

// Nodes at equal nonlinear height form an antichain. The feedback epoch also
// prevents any grouping across a client-side token selection. Materializing a
// batch recursively emits all its ancestors first, then contiguous extraction
// views, preserving the externally observable output order.
inline auto batch_packed_polynomials(PackedProgram program, PackedOptimizationStats& stats)
    -> PackedProgram {
  const int count = program.nodes.size();
  stats.original_nodes = count;
  const auto depth = plan_packed_depth(program);
  std::vector<int> height(count), group_of(count, -1);
  std::map<std::tuple<int, int, int>, std::vector<int>> buckets;
  int epoch = 0;
  for (int i = 0; i < count; ++i) {
    const auto& node = program.nodes[i];
    if (node.operation == "feedback") ++epoch;
    for (int parent : node.parents) height[i] = std::max(height[i], height[parent]);
    if (node.operation == "cheb") {
      ++height[i];
      if (depth.live[i]) buckets[{epoch, height[i], static_cast<int>(node.data.size())}].push_back(i);
    }
  }
  std::vector<std::vector<int>> groups;
  for (const auto& [key, indices] : buckets) {
    std::vector<int> group;
    int occupied = 0;
    auto finish = [&] {
      if (group.size() > 1) {
        for (int i : group) group_of[i] = groups.size();
        groups.push_back(group);
      }
      group.clear(); occupied = 0;
    };
    for (int i : indices) {
      if (occupied + program.nodes[i].size > program.slots) finish();
      group.push_back(i); occupied += program.nodes[i].size;
    }
    finish();
  }
  PackedProgram out{program.slots, program.bound, {}, {}};
  std::vector<int> mapped(count, -1), visiting(count);
  std::map<int, int> weights;
  std::function<int(int)> emit = [&](int i) -> int {
    if (mapped[i] >= 0) return mapped[i];
    if (visiting[i]) throw std::logic_error("polynomial batch creates a dependency cycle");
    visiting[i] = 1;
    if (group_of[i] >= 0) {
      const auto& group = groups[group_of[i]];
      PackedNode batch{"cheb_batch", 0, {}, {}, 0};
      for (int index : group) {
        const auto& node = program.nodes[index];
        batch.parents.push_back(emit(node.parents[0]));
        batch.size += node.size;
        batch.bound = std::max(batch.bound, node.bound);
        batch.polynomials.push_back({node.size, node.data});
      }
      const int combined = out.nodes.size();
      out.nodes.push_back(std::move(batch));
      int offset = 0;
      for (int index : group) {
        const auto& node = program.nodes[index];
        std::vector<double> indices(node.size);
        std::iota(indices.begin(), indices.end(), offset);
        mapped[index] = out.nodes.size();
        out.nodes.push_back({"gather", node.size, {combined}, std::move(indices), node.bound});
        offset += node.size;
      }
      ++stats.polynomial_batches;
      stats.grouped_polynomials += group.size();
      stats.maximum_batch = std::max(stats.maximum_batch, static_cast<int>(group.size()));
    } else {
      auto& node = program.nodes[i];
      std::vector<int> parents;
      for (int parent : node.parents) parents.push_back(emit(parent));
      if (node.operation == "linear" || node.operation == "linear_ref") {
        const int owner = node.operation == "linear" ? i : static_cast<int>(node.data[0]);
        if (weights.count(owner)) {
          mapped[i] = out.nodes.size();
          out.nodes.push_back({"linear_ref", node.size, std::move(parents),
                               {static_cast<double>(weights[owner])}, node.bound});
        } else {
          auto& original = program.nodes[owner];
          PackedNode copied{"linear", node.size, std::move(parents), std::move(original.data), node.bound};
          copied.bf16_weights = std::move(original.bf16_weights);
          mapped[i] = weights[owner] = out.nodes.size();
          out.nodes.push_back(std::move(copied));
        }
      } else {
        mapped[i] = out.nodes.size();
        node.parents = std::move(parents);
        out.nodes.push_back(std::move(node));
      }
    }
    visiting[i] = 2;
    return mapped[i];
  };
  // Preserve the original traversal as far as possible. Only a batch's
  // additional ancestors are advanced; dead nodes are omitted.
  for (int i = 0; i < count; ++i) if (depth.live[i]) emit(i);
  for (auto& output : program.outputs) {
    output.node = mapped[output.node];
    out.outputs.push_back(std::move(output));
  }
  stats.optimized_nodes = out.nodes.size();
  return out;
}
}  // namespace fhemamba
