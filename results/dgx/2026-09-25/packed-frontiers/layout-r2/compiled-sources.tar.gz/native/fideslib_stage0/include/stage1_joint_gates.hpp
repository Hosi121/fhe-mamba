#pragma once

#include "vector_chebyshev.hpp"

#include <algorithm>
#include <cmath>
#include <functional>
#include <map>
#include <stdexcept>
#include <utility>
#include <vector>

namespace fhemamba::stage1 {

struct JointGateSpec {
  // Degree-major, head-minor coefficients in the ordinary Chebyshev convention.
  std::vector<double> lo, hi, p, q, rates;
};

inline auto joint_coefficient_slots(const std::vector<double>& row, int batch,
                                   int stride, int offset, int streams) -> std::vector<double> {
  if (batch < 1 || stride < 1 || streams < 1 || streams * stride > batch ||
      offset < 0 || offset + static_cast<int>(row.size()) > stride)
    throw std::runtime_error("invalid joint coefficient slot layout");
  std::vector<double> slots(static_cast<std::size_t>(batch), 0.0);
  for (int stream = 0; stream < streams; ++stream)
    std::copy(row.begin(), row.end(), slots.begin() + stream * stride + offset);
  return slots;
}

// A periodic coefficient vector agrees with the sparse vector on every head
// lane. It may only multiply a value supported on those lanes: in particular,
// Chebyshev T0 and the even-degree recurrence must use the head mask, not 1.
inline auto joint_periodic_coefficient_slots(const std::vector<double>& row, int batch,
                                            int stride, int offset, int streams)
    -> std::vector<double> {
  if (row.empty() || batch < 1 || stride < 1 || streams < 1 ||
      streams > batch / stride || offset < 0 || offset > stride ||
      row.size() > static_cast<std::size_t>(stride - offset))
    throw std::runtime_error("invalid periodic joint coefficient layout");
  int period = 1;
  while (period < static_cast<int>(row.size())) period *= 2;
  if (batch % period != 0 || stride % period != 0)
    throw std::runtime_error("joint coefficient period must divide batch and stream stride");
  std::vector<double> slots(static_cast<std::size_t>(period), 0.0);
  for (std::size_t h = 0; h < row.size(); ++h)
    slots[(static_cast<std::size_t>(offset) + h) % period] = row[h];
  return slots;
}

inline void validate_joint_gate(const JointGateSpec& spec, int heads) {
  if (heads < 1 || spec.lo.size() != static_cast<std::size_t>(heads) ||
      spec.hi.size() != spec.lo.size() || spec.rates.size() != spec.lo.size())
    throw std::runtime_error("joint gate requires one domain/rate per head");
  for (const auto* values : {&spec.lo, &spec.hi, &spec.p, &spec.q, &spec.rates})
    if (!std::all_of(values->begin(), values->end(), [](double x) { return std::isfinite(x); }))
      throw std::runtime_error("joint gate contains non-finite values");
  for (int h = 0; h < heads; ++h)
    if (spec.lo[h] >= spec.hi[h] || spec.rates[h] <= 0)
      throw std::runtime_error("invalid joint gate domain/rate");
  for (const auto* coefficients : {&spec.p, &spec.q})
    if (coefficients->empty() || coefficients->size() % heads != 0 ||
        coefficients->size() / heads > 4097)
      throw std::runtime_error("invalid joint gate coefficient matrix shape");
}

// Vector-coefficient Paterson-Stockmeyer decomposition. All heads share the
// encrypted Chebyshev basis while their domains/coefficients remain distinct.
// No coefficient threshold, interpolation, or domain clipping occurs here.
template <typename Value, typename Ops>
auto evaluate_joint_roots(const Value& input, const JointGateSpec& spec, Ops& ops)
    -> std::pair<Value, Value> {
  const int heads = static_cast<int>(spec.lo.size());
  validate_joint_gate(spec, heads);
  const int degree = static_cast<int>(std::max(spec.p.size(), spec.q.size())) / heads - 1;
  auto values = fhemamba::evaluate_vector_chebyshev(input, heads, degree,
      std::vector<std::vector<double>>{spec.p, spec.q}, ops);
  return {values[0], values[1]};
}

}  // namespace fhemamba::stage1
