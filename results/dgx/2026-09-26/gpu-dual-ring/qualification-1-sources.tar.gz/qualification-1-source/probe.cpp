// Standalone encrypted GPU feasibility probe; no trained-model speed claim.
#include "ring_map.hpp"
#include <fideslib.hpp>
#include <CKKS/Ciphertext.cuh>
#include <CKKS/Context.cuh>
#include <CKKS/KeySwitchingKey.cuh>
#include <CKKS/openfhe-interface/RawCiphertext.cuh>
#include <openfhe.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <type_traits>

namespace gpu = FIDESlib::CKKS;
using namespace fideslib;
using Ct = Ciphertext<DCRTPoly>;
using Context = CryptoContext<DCRTPoly>;
using CpuContext = lbcrypto::CryptoContext<lbcrypto::DCRTPoly>;
using Clock = std::chrono::steady_clock;

void sync_gpu() {
  auto e = cudaDeviceSynchronize();
  if (e != cudaSuccess) throw std::runtime_error(cudaGetErrorString(e));
}
double seconds(Clock::time_point t) { sync_gpu(); return std::chrono::duration<double>(Clock::now()-t).count(); }
CpuContext cpu(const Context& c) { return std::any_cast<CpuContext>(c->cpu); }
std::shared_ptr<gpu::Ciphertext> device(const Ct& c) {
  return std::static_pointer_cast<gpu::Ciphertext>(c->parent_context->GetDeviceCiphertext(c->gpu));
}
auto cp(const Context& c) {
  return std::dynamic_pointer_cast<lbcrypto::CryptoParametersCKKSRNS>(cpu(c)->GetCryptoParameters());
}

// OpenFHE's host NTT cache is keyed by modulus, not ring degree. Only setup,
// public reference checks and final client decoding use this serialized helper.
void select_cpu(const Context& c) {
  intnat::ChineseRemainderTransformFTTNat<lbcrypto::NativeVector> ntt;
  ntt.Reset();
  for (const auto& params : {cp(c)->GetElementParams(), cp(c)->GetParamsP()})
    for (const auto& limb : params->GetParams())
      ntt.PreCompute(limb->GetRootOfUnity(), limb->GetCyclotomicOrder(), limb->GetModulus());
}

Context context(int n) {
  CCParams<CryptoContextCKKSRNS> p;
  p.SetSecurityLevel(HEStd_NotSet); p.SetSecretKeyDist(UNIFORM_TERNARY);
  p.SetCKKSDataType(REAL); p.SetRingDim(n); p.SetBatchSize(n/2);
  p.SetMultiplicativeDepth(44); p.SetScalingModSize(59); p.SetFirstModSize(60);
  p.SetScalingTechnique(FLEXIBLEAUTO); p.SetKeySwitchTechnique(HYBRID);
  p.SetNumLargeDigits(3); p.SetDevices({0});
  p.SetPlaintextAutoload(false); p.SetCiphertextAutoload(true);
  auto c = GenCryptoContext(p);
  for (auto f : {PKE, KEYSWITCH, LEVELEDSHE, ADVANCEDSHE, FHE}) c->Enable(f);
  return c;
}

// Preserve every Q modulus and flexible scale of the full model context.
void match_small_parameters(const Context& small, const Context& large) {
  std::vector<lbcrypto::NativeInteger> q, roots;
  for (const auto& p : cp(large)->GetElementParams()->GetParams()) {
    q.push_back(p->GetModulus());
    roots.push_back(p->GetRootOfUnity().ModMul(p->GetRootOfUnity(), p->GetModulus()));
  }
  auto p = cp(small);
  p->SetElementParams(std::make_shared<lbcrypto::DCRTPoly::Params>(65536, q, roots));
  p->PrecomputeCRTTables(p->GetKeySwitchTechnique(), p->GetScalingTechnique(),
      p->GetEncryptionTechnique(), p->GetMultiplicationTechnique(), p->GetNumPartQ(),
      p->GetAuxBits(), p->GetExtraBits());
  for (int i=0; i<=44; ++i)
    if (p->GetScalingFactorReal(i) != cp(large)->GetScalingFactorReal(i))
      throw std::runtime_error("different flexible scale");
}

// Every transfer includes an encrypted key switch in the large ring. The small
// secret is embedded as s(X^2), never substituted for the dense refresh secret.
class RingBridge {
  Context large_, small_;
  Ct large_template_, small_template_;
  std::string large_id_, small_id_;
  std::unique_ptr<gpu::KeySwitchingKey> down_, up_;
 public:
  RingBridge(Context large, Context small, const KeyPair<DCRTPoly>& lk,
             const KeyPair<DCRTPoly>& sk, Ct lt, Ct st)
      : large_(large), small_(small), large_template_(lt), small_template_(st) {
    auto lsk = std::any_cast<lbcrypto::PrivateKey<lbcrypto::DCRTPoly>>(lk.secretKey->pimpl);
    auto ssk = std::any_cast<lbcrypto::PrivateKey<lbcrypto::DCRTPoly>>(sk.secretKey->pimpl);
    large_id_ = lsk->GetKeyTag(); small_id_ = ssk->GetKeyTag();
    // NTT embedding is exact because both contexts use squared compatible roots.
    lbcrypto::DCRTPoly lifted(cp(large)->GetElementParams(), Format::EVALUATION, true);
    const auto& s = ssk->GetPrivateElement();
    for (std::size_t j=0; j<lifted.GetNumOfElements(); ++j)
      for (std::size_t i=0; i<32768; ++i) {
        lifted.GetAllElements().at(j)[2*i] = s.GetElementAtIndex(j)[i];
        lifted.GetAllElements().at(j)[2*i+1] = s.GetElementAtIndex(j)[i];
      }
    auto embedded = std::make_shared<lbcrypto::PrivateKeyImpl<lbcrypto::DCRTPoly>>(cpu(large));
    embedded->SetPrivateElement(std::move(lifted)); embedded->SetKeyTag(small_id_);
    select_cpu(large);
    auto& gc = std::any_cast<gpu::Context&>(large->gpu);
    auto make_key = [&](auto from, auto to, const std::string& source_id) {
      auto key = std::dynamic_pointer_cast<lbcrypto::EvalKeyRelinImpl<lbcrypto::DCRTPoly>>(
          cpu(large)->GetScheme()->KeySwitchGen(from, to));
      auto raw = gpu::GetKeySwitchKey(key);
      raw.keyid = source_id;
      auto out = std::make_unique<gpu::KeySwitchingKey>(gc);
      out->Initialize(raw); sync_gpu(); return out;
    };
    down_ = make_key(lsk, embedded, large_id_);
    up_ = make_key(embedded, lsk, small_id_);
  }

  Ct map(const Ct& input, bool expand) const {
    const auto& dest = expand ? large_ : small_;
    const auto& prototype = expand ? large_template_ : small_template_;
    auto source = device(input);
    auto& gc = std::any_cast<gpu::Context&>(dest->gpu);
    sync_gpu(); gpu::SetCurrentContext(gc); sync_gpu();
    auto target = std::make_shared<gpu::Ciphertext>(gc);
    const int level = source->getLevel();
    target->c0.grow(level); target->c1.grow(level);
    for (auto pair : {std::pair{&source->c0, &target->c0}, std::pair{&source->c1, &target->c1}}) {
      for (int j=0; j<=level; ++j) {
        auto a = source->cc.limbGPUid.at(j), b = target->cc.limbGPUid.at(j);
        const uint64_t* from = nullptr; uint64_t* to = nullptr;
        std::visit([&](auto& limb) {
          if constexpr(std::is_same_v<decltype(limb.v.data), uint64_t*>) from = limb.v.data;
        }, pair.first->GPU.at(a.x).limb.at(a.y));
        cudaStream_t stream{};
        std::visit([&](auto& limb) {
          if constexpr(std::is_same_v<decltype(limb.v.data), uint64_t*>) to = limb.v.data;
          stream = limb.stream.ptr();
        }, pair.second->GPU.at(b.x).limb.at(b.y));
        if (!from || !to || source->cc.prime.at(j).p != target->cc.prime.at(j).p)
          throw std::runtime_error("incompatible GPU ring-map limb");
        ring_map(from, to, 32768, source->cc.prime.at(j).p, expand, stream);
      }
    }
    target->NoiseFactor = source->NoiseFactor; target->NoiseLevel = source->NoiseLevel;
    target->slots = expand ? 32768 : 16384; target->keyID = small_id_;
    sync_gpu();
    auto out = std::make_shared<CiphertextImpl<DCRTPoly>>(Context(dest));
    out->cpu = prototype->cpu; out->need_lazy_copy = true;
    out->gpu = dest->RegisterDeviceCiphertext(std::move(target)); out->loaded = true;
    return out;
  }
  Ct down(const Ct& input) const {
    auto temp = input->Clone();
    device(temp)->keySwitch(*down_); sync_gpu();
    return map(temp, false);
  }
  Ct up(const Ct& input) const {
    auto out = map(input, true);
    device(out)->keySwitch(*up_); sync_gpu(); device(out)->keyID = large_id_;
    return out;
  }
};

Ct encrypt(const Context& c, const KeyPair<DCRTPoly>& keys, const std::vector<double>& v) {
  select_cpu(c);
  auto p = c->MakeCKKSPackedPlaintext(v);
  auto out = c->Encrypt(keys.publicKey, p); sync_gpu(); return out;
}
double error(const Context& c, const KeyPair<DCRTPoly>& keys, const Ct& ct,
             const std::vector<double>& expected) {
  select_cpu(c); Plaintext p; auto copy = ct->Clone();
  c->Decrypt(keys.secretKey, copy, &p); p->SetLength(expected.size());
  const auto actual = p->GetRealPackedValue(); double worst = 0;
  for (std::size_t i=0; i<expected.size(); ++i) {
    if (!std::isfinite(actual.at(i))) throw std::runtime_error("nonfinite client output");
    worst = std::max(worst, std::abs(actual.at(i)-expected[i]));
  }
  return worst;
}

Ct refresh(const Context& c, Ct input) {
  while (input->GetNoiseScaleDeg()>1) c->RescaleInPlace(input);
  auto first = c->EvalBootstrap(input); sync_gpu();
  auto a = input->Clone(), b = first->Clone();
  while (b->GetNoiseScaleDeg()>1) c->RescaleInPlace(b);
  const auto target = std::max(a->GetLevel(), b->GetLevel());
  for (auto* x : {&a, &b})
    while ((*x)->GetLevel()<target) {
      c->EvalMultInPlace(*x, 1.0);
      while ((*x)->GetNoiseScaleDeg()>1) c->RescaleInPlace(*x);
    }
  auto residual = c->EvalSub(a,b); c->EvalMultInPlace(residual,4096.0);
  while (residual->GetNoiseScaleDeg()>1) c->RescaleInPlace(residual);
  auto second = c->EvalBootstrap(residual); sync_gpu();
  c->EvalMultInPlace(second, 1.0/4096.0);
  c->EvalMultInPlace(first, 1.0);
  auto out = c->EvalAdd(first,second); sync_gpu(); return out;
}

struct Sample { int width, iteration; bool small; double ordinary, up, boot, down, err; int level; };

int main(int argc, char** argv) {
  try {
    if (argc != 3) throw std::invalid_argument("usage: gpu_dual_ring OUTPUT qualification|abba|baab");
    const std::string mode = argv[2];
    if (mode!="qualification" && mode!="abba" && mode!="baab") throw std::invalid_argument("mode");
    const auto started = Clock::now();
    auto large = context(65536), small = context(32768);
    match_small_parameters(small, large);
    select_cpu(large); auto lk = large->KeyGen(); large->EvalMultKeyGen(lk.secretKey);
    large->EvalRotateKeyGen(lk.secretKey, {1, -1, 24});
    large->EvalBootstrapSetup({4,4}, {0,0}, 32768, 0, true);
    large->EvalBootstrapKeyGen(lk.secretKey, 32768);
    large->LoadContext(lk.publicKey); sync_gpu();
    std::cerr << "large context ready\n";
    select_cpu(small); auto sk = small->KeyGen(); small->EvalMultKeyGen(sk.secretKey);
    small->EvalRotateKeyGen(sk.secretKey, {1,-1,24}); small->LoadContext(sk.publicKey); sync_gpu();
    std::cerr << "small context ready\n";
    auto lt = encrypt(large,lk,std::vector<double>(32768,.1));
    auto st = encrypt(small,sk,std::vector<double>(16384,.1));
    RingBridge bridge(large,small,lk,sk,lt,st);
    const double setup = seconds(started);
    std::vector<Sample> samples; double worst = 0;
    // First qualify both transfer directions, all slots, and scale degrees.
    int cases = 0;
    for (int level : {18,26,34}) for (int width : {1,32,768,1536,16384}) {
      std::vector<double> sv(16384), lv(32768);
      for (int i=0;i<width;++i) sv[i]=.6*std::sin(i*.71+.1);
      for (int i=0;i<32768;++i) lv[i]=sv[i%16384];
      auto s = encrypt(small,sk,sv), l = encrypt(large,lk,lv);
      s->SetLevel(level); l->SetLevel(level);
      for (bool degree2 : {false,true}) {
        auto sc=s->Clone(),lc=l->Clone();
        auto se=sv,le=lv;
        if (degree2) {
          small->EvalMultInPlace(sc,.75); large->EvalMultInPlace(lc,.75);
          for(auto& v:se)v*=.75; for(auto& v:le)v*=.75;
        }
        auto up=bridge.up(sc), down=bridge.down(lc);
        auto e=std::max(error(large,lk,up,le),error(small,sk,down,se));
        worst=std::max(worst,e); ++cases;
        if(e>1e-6) throw std::runtime_error("transfer numerical failure: "+std::to_string(e));
      }
      std::cerr<<"transfer level="<<level<<" width="<<width<<" worst="<<worst<<'\n';
    }
    const std::vector<int> widths = mode=="qualification" ? std::vector<int>{1,32,768,1536} : std::vector<int>{1536};
    for (int width : widths) {
      std::vector<double> sv(16384),lv(32768);
      for(int i=0;i<width;++i)sv[i]=.6*std::sin(i*.71+.1);
      for(int i=0;i<32768;++i)lv[i]=sv[i%16384];
      auto s=encrypt(small,sk,sv),l=encrypt(large,lk,lv);
      s->SetLevel(18); l->SetLevel(18);
      const std::string order=mode=="qualification"?"ab":mode;
      for(int iteration=-1;iteration<int(order.size());++iteration) {
        const bool sm=iteration<0?true:order[iteration]=='b';
        auto c=sm?small:large; auto input=sm?s:l;
        auto expected=sm?sv:lv;
        sync_gpu(); auto begin=Clock::now();
        // Eight levels of bounded, nonconstant encrypted polynomial work.
        auto out=input->Clone();
        for(int k=0;k<8;++k) {
          out=c->EvalMult(out,out); c->EvalAddInPlace(out,.125);
          for(auto& v:expected)v=v*v+.125;
        }
        while(out->GetNoiseScaleDeg()>1)c->RescaleInPlace(out);
        double ordinary=seconds(begin),up=0,down=0;
        begin=Clock::now();
        auto full=sm?bridge.up(out):out;
        if(sm)up=seconds(begin);
        // Fixed model input budget; consumes scale through arithmetic, no reset.
        full->SetLevel(34); sync_gpu(); begin=Clock::now();
        full=refresh(large,full); double boot=seconds(begin);
        begin=Clock::now(); out=sm?bridge.down(full):full;
        if(sm)down=seconds(begin);
        begin=Clock::now(); out=c->EvalMult(out,out); ordinary+=seconds(begin);
        for(auto& v:expected)v*=v;
        auto e=error(c,sm?sk:lk,out,expected); worst=std::max(worst,e);
        samples.push_back({width,iteration,sm,ordinary,up,boot,down,e,int(out->GetLevel())});
        std::cerr<<"sample width="<<width<<" small="<<sm<<" ordinary="<<ordinary<<" up="<<up<<" refresh="<<boot<<" down="<<down<<" error="<<e<<'\n';
      }
    }
    std::ofstream report(argv[1]); report<<std::setprecision(15)
      <<"{\"passed\":"<<(worst<=1e-6?"true":"false")<<",\"mode\":\""<<mode
      <<"\",\"tolerance\":1e-6,\"setup_seconds\":"<<setup<<",\"transfer_cases\":"<<cases
      <<",\"max_abs_error\":"<<worst<<",\"evaluator_decryptions\":0,\"depth\":44,\"scale_bits\":59,\"bootstrap_passes\":2,\"s2c_first\":true,\"samples\":[";
    for(std::size_t i=0;i<samples.size();++i) {
      auto a=samples[i]; if(i)report<<',';
      report<<"{\"width\":"<<a.width<<",\"iteration\":"<<a.iteration<<",\"small\":"<<(a.small?"true":"false")
        <<",\"ordinary_seconds\":"<<a.ordinary<<",\"up_seconds\":"<<a.up<<",\"refresh_seconds\":"<<a.boot
        <<",\"down_seconds\":"<<a.down<<",\"error\":"<<a.err<<",\"output_level\":"<<a.level<<'}';
    }
    report<<"]}\n"; return worst<=1e-6?0:2;
  } catch(const std::exception& e) { std::cerr<<"FAILED: "<<e.what()<<'\n'; return 2; }
}
