#pragma once
#include <pthread.h>
#include <sched.h>
#include <omp.h>
#include <cstdio>
#include <stdexcept>
inline void benchmark_pin_prefetch_worker(std::size_t worker) {
  const int previous = omp_get_max_active_levels();
  omp_set_max_active_levels(0);
  // Initialize the foreign thread's OpenMP state before selecting its CPU.
  #pragma omp parallel num_threads(1)
  { asm volatile ("" ::: "memory"); }
  omp_set_max_active_levels(previous);
  cpu_set_t cpus; CPU_ZERO(&cpus); CPU_SET(65 + worker, &cpus);
  if (pthread_setaffinity_np(pthread_self(), sizeof(cpus), &cpus))
    throw std::runtime_error("benchmark prefetch CPU affinity failed");
  char name[16]; std::snprintf(name, sizeof(name), "fhe-prefetch%zu", worker);
  pthread_setname_np(pthread_self(), name);
}
